# Registro de contraste técnico · motor 0.2.0

Documento fuente: PDF aportado por el usuario, 1140 páginas. SHA-256:
`f687753a9368ccdf88833975ae9c9c0c9f8d5908e9d8a711020778ac87f8ce6d`.

El contraste fue realizado por el asistente sobre el texto y las páginas renderizadas.
No es revisión ni firma de un profesional responsable de una instalación.

## Correcciones con evidencia

| Área | Comportamiento anterior | Cambio y fuente |
| --- | --- | --- |
| Encabezados | Citas al inicio de línea confundidas con secciones | Contexto del artículo, negrita y coordenadas; 33 candidatos descartados con evidencia en `NOM.audit.json` |
| Final de artículos | Último artículo continuaba hasta el final del PDF | El capítulo siguiente cierra el artículo y su última sección; evita incluir las tablas/anexos |
| Temperatura | Rangos desplazados; 35 °C recibía 1.00 | Columna 75 °C de 310-15(b)(2)(a), base 30 °C: 35 °C → 0.94; 40 °C → 0.88; 65 °C → 0.47. Página PDF 186 |
| Agrupamiento | 11–20 recibían 0.45; 21–30, 0.40 | 10–20 → 0.50; 21–30 → 0.45; 31–40 → 0.40. Página 187 |
| Ampacidad de aluminio | 80% aproximado de cobre | Columna real de 75 °C: AWG 6 → 50 A; AWG 4 → 65 A. No se inventan valores para tamaños sin dato. Página 190 |
| Resistencia de aluminio | Resistencia de cobre × 1.62 | Columnas independientes de Tabla 9; AWG 6 en PVC → 2.66 ohm/km. Página 1011 |
| Paralelos | Ampacidad no consideraba conductores por fase | Carga repartida entre conductores; mínimo 1/0 en la selección soportada. Comprobar requisitos completos y conteo de portadores |
| Capacidad interruptiva | Si se superaban 200 kA se devolvía 200 kA | Se rechaza una selección fuera del catálogo implementado |
| Puesta a tierra de equipos | Dimensionamiento desde corriente de carga o V/R; tablas aproximadas | Tabla 250-122 según capacidad/ajuste del dispositivo. Para 400 A, cobre AWG 2. Página 151 |
| Resistencia de tierra | 25 ohm como máximo universal; 5 ohm como recomendación atribuida a la norma | Alcance explícito de la excepción de 250-53(a)(2), página 134. Sin contexto no se emite juicio sobre ese criterio |
| Reglas vacías | 100% de cumplimiento y aprobación sin evaluaciones | Cero evaluaciones → no aprobado; interfaz indica que no hay reglas aplicables |
| Resultados preliminares | Selecciones de motor/transformador marcadas como cumplidas con datos insuficientes | Conservan resultados ilustrativos, pero no afirman conformidad. La referencia al 125% no se presenta como protección máxima universal |

Los valores estructurados están en `config/normas/tablas_75c.json`. `fuentes` en cada
resultado contrastado identifica tabla, página, SHA-256 y ausencia de revisión profesional.

## Límites explícitos

- Tablas 310-15: solo columna de 75 °C y base de 30 °C para el flujo implementado.
  No extrapolar correcciones ambientales por encima de 70 °C.
- Los calibres admitidos son un subconjunto de la tabla completa; no se han añadido
  todas las opciones de aislamiento, temperatura de terminal, instalación o excepciones.
- Tabla 9: conservar sus hipótesis de temperatura, frecuencia, configuración y notas.
  La aplicación a monofásicos o paralelos requiere comprobar el modelo físico.
- Tabla 250-122: conductor de equipos; no dimensiona el conductor al electrodo de
  250-66. La resistencia del terreno no sustituye el lazo de falla completo.
- El umbral de 25 ohm no certifica un sistema ni se aplica a todos los electrodos.
- Demanda, motores, protección de transformadores y varias reglas heredadas siguen
  pendientes de contraste completo. Ningún indicador parcial valida toda la instalación.
- Los proyectos importados se recalculan. Su archivo no es una firma digital ni
  garantiza autenticidad de un resultado histórico aportado por terceros.

## Próximos trabajos técnicos

1. Revisar procedimientos de demanda por tipo de inmueble y categoría de carga.
2. Modelar dispositivos de protección y casos específicos de 430-52 y 450-3.
3. Añadir selección de temperatura de aislamiento/terminal y condiciones de instalación.
4. Completar 250-66, excepciones y casos de puesta a tierra con pruebas independientes.
5. Revisión profesional externa de casos completos y de la transcripción normativa.
