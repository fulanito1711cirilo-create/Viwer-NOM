# Publicación del MCP por HTTPS

## Estado comprobado

La imagen Docker se construyó con el PDF real y se probó con un cliente MCP por
Streamable HTTP. El endpoint de datos es `/mcp`; el de salud, `/healthz`.
Esto valida el paquete. No se ha creado un servicio en un proveedor externo ni
asignado una URL pública: el entorno actual no tiene cuenta de despliegue ni
función de publicación de puertos conectada.

## Imagen portable

El contexto de construcción debe contener `data/NOM.pdf`. La copia proporcionada
está en esta nube, pero Git la ignora. El paquete de publicación preparado incluye
el PDF y el código necesario; no incluye proyectos de sesiones, credenciales ni
los otros repositorios del entorno.

```bash
docker build -t nom-mcp .
docker run --rm --read-only --tmpfs /tmp --cap-drop ALL \
  --security-opt no-new-privileges \
  -p 8000:8000 -e PORT=8000 \
  -e MCP_PUBLIC_URL=https://TU-DOMINIO \
  nom-mcp
```

Los comandos anteriores son para el servidor destino. `TU-DOMINIO` es un marcador
que debe sustituirse por el dominio HTTPS real. La imagen no instala un certificado
ni abre HTTPS por sí misma: el proveedor o proxy inverso debe terminar TLS.

En la nube Codex, los builds requieren conservar el proxy e introducir su CA como
secreto BuildKit, sin incorporarla a capas:

```bash
docker build --secret id=proxy_ca,src=/etc/ssl/certs/ca-certificates.crt -t nom-mcp .
```

## Render

Se proporciona `render.yaml` para un servicio web Docker con comprobación de salud.
Render asigna HTTPS y establece `RENDER_EXTERNAL_HOSTNAME`, que el servidor incorpora
a los hosts permitidos. Para dominio propio, definir `MCP_PUBLIC_URL` con su origen
HTTPS (sin `/mcp`).

Hace falta una cuenta Render autorizada y una fuente de despliegue accesible para
ella. El repositorio configurado o la imagen publicada deben contener el PDF:
una clonación del Git actual no basta porque `data/NOM.pdf` está ignorado. Puede
usarse el paquete completo como fuente para un repositorio de despliegue; incluir
el PDF implica publicarlo junto al servicio, de acuerdo con el propósito solicitado.
No se ha subido ese paquete ni creado recursos remotos en esta tarea.

## Variables

| Variable | Uso |
| --- | --- |
| `PORT` | Puerto HTTP; predeterminado 8000 |
| `MCP_PUBLIC_URL` | Origen HTTPS público, sin ruta; requerido fuera de Render |
| `RENDER_EXTERNAL_HOSTNAME` | Host inyectado automáticamente por Render |
| `MCP_ALLOWED_ORIGINS` | Orígenes de navegador adicionales, separados por comas |
| `MCP_REQUESTS_PER_MINUTE` | Cuota global por proceso; predeterminado 300 |
| `MCP_MAX_CONCURRENT` | Peticiones simultáneas por proceso; predeterminado 8 |
| `NOM_PDF_PATH` | PDF local; la imagen usa `/app/data/NOM.pdf` |

Solo se admiten los hosts configurados y los locales de diagnóstico. La protección
contra DNS rebinding sigue activa. Los orígenes de ChatGPT están permitidos para el
protocolo. Un cliente MCP ejecutado desde servidor normalmente no envía `Origin`.
No se añadió CORS abierto para páginas web arbitrarias.

La API es pública y sin autenticación, como fue solicitada. Expone consultas y
cálculos; no ofrece escritura de archivos ni acceso a los proyectos de usuarios.
Las cuotas de la aplicación son por proceso; un proveedor puede aplicar controles
adicionales de capacidad. No se incorpora un mecanismo OAuth en esta versión.

## Validar el servicio publicado

Con el dominio real:

```bash
python scripts/check_remote_mcp.py https://TU-DOMINIO/mcp
```

Este script comprueba salud, inicialización MCP, descubrimiento y herramientas.
Después, en un cliente compatible con MCP remoto, usar la URL HTTPS completa
terminada en `/mcp`, con autenticación «ninguna» si ofrece esa opción. No utilizar
una dirección de loopback como conector remoto de ChatGPT.

La integración concreta depende de las opciones MCP disponibles en la cuenta del
cliente. No se ha registrado automáticamente una conexión en cuentas externas.

## Windows como servidor temporal

El paquete Windows incluye instalador nativo Python y accesos `.cmd`; Docker no es
necesario. Consultar `LEEME-WINDOWS.txt`. `windows/launcher.py` puede instalar
`Cloudflare.cloudflared` con winget, obtiene una URL de Quick Tunnel, configura
el host público exacto y vincula el backend solo a `127.0.0.1`. Verifica salud y
protocolo MCP a través de HTTPS antes de anunciar la dirección.

Se usa Streamable HTTP con respuestas JSON; no depende de una conexión SSE
persistente para los resultados. El túnel temporal no garantiza disponibilidad ni
URL estable. No instala un servicio permanente ni cambia el router. Al detenerse,
termina los procesos que inició. La instalación y el túnel reales de Windows no
se han ejecutado desde este entorno Linux; se probaron las funciones auxiliares y
su ciclo de vida con procesos simulados.
