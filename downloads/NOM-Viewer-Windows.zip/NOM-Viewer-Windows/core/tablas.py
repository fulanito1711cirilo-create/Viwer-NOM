"""Datos transcritos con procedencia; no sustituye revisar condiciones de aplicación."""
import json
import math
from pathlib import Path

DATOS = json.loads((Path(__file__).resolve().parents[1] / 'config/normas/tablas_75c.json').read_text(encoding='utf-8'))
TABLAS = DATOS['tablas']


def fuente(clave):
    return {'referencia':clave, 'pagina_pdf':TABLAS[clave]['pagina_pdf'], 'sha256':DATOS['sha256'],
            'uri':f"nom://{DATOS['sha256']}/paginas/{TABLAS[clave]['pagina_pdf']}",
            'estado':DATOS['estado'], 'revision_profesional':False}


def factor_temperatura_75(temperatura):
    if not math.isfinite(temperatura):
        raise ValueError('La temperatura debe ser finita.')
    for rango in TABLAS['tab310-15b2a']['rangos']:
        if temperatura <= rango['max_c']:
            return rango['factor']
    raise ValueError('No hay factor tabulado para conductor de 75 °C por encima de 70 °C ambiente.')


def factor_agrupamiento(numero):
    if isinstance(numero,bool) or not isinstance(numero,int) or numero < 1:
        raise ValueError('El número de conductores debe ser un entero positivo.')
    for rango in TABLAS['tab310-15b3a']['rangos']:
        if rango['max'] is None or numero <= rango['max']:
            return rango['factor']


def consultar_tabla(referencia):
    from copy import deepcopy
    if referencia not in TABLAS:
        raise ValueError('Tabla estructurada no disponible. Opciones: ' + ', '.join(TABLAS))
    return {'fuente':fuente(referencia), 'datos':deepcopy(TABLAS[referencia])}


def dimensionar_tierra_equipos(corriente_dispositivo_a: float, material: str = 'Cobre') -> dict:
    """Tabla 250-122: usa capacidad/ajuste del dispositivo, no carga ni corriente V/R. No aplica a conductor del electrodo."""
    if not math.isfinite(corriente_dispositivo_a) or corriente_dispositivo_a <= 0:
        raise ValueError('La capacidad del dispositivo debe ser positiva y finita.')
    if material not in ('Cobre','Aluminio'):
        raise ValueError('Material debe ser Cobre o Aluminio.')
    fila=next((f for f in TABLAS['tab250-122']['filas'] if corriente_dispositivo_a <= f['max_dispositivo_a']),None)
    if fila is None:
        raise ValueError('La capacidad supera el máximo tabulado (6000 A).')
    calibre=fila[material.lower()]
    if calibre is None:
        raise ValueError('La tabla no proporciona calibre de aluminio para este rango; no se extrapola.')
    return {'calibre':calibre, 'unidad_calibre':'AWG' if '/' in calibre or int(calibre)<=14 else 'kcmil',
            'corriente_dispositivo_a':corriente_dispositivo_a,'fila_max_dispositivo_a':fila['max_dispositivo_a'],
            'fuente':fuente('tab250-122'), 'alcance':TABLAS['tab250-122']['alcance']}
