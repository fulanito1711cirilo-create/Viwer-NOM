"""Versión del motor que acompaña cada resultado reproducible."""
MOTOR_VERSION = '0.2.0'
