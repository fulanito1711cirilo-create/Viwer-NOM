"""Índice normativo sin dependencias de Streamlit."""
import re
from collections import defaultdict
from functools import lru_cache
from config.normas.nom_001_sede_2012 import MAPA

def _construir_indice_jerarquico(mapa: dict[str, int]) -> dict:
    indice = {"articulos": defaultdict(lambda: {"pagina": None, "subs": {}}),
              "tablas": defaultdict(lambda: {"pagina": None, "subs": {}})}
    for clave, pagina in mapa.items():
        if clave.startswith("art"):
            tipo = "articulos"
            match = re.match(r'(art\d+)(?:-(.*))?', clave)
            if match:
                base = match.group(1)
                sub = match.group(2)
                entrada = indice[tipo][base]
                if sub is None:
                    entrada["pagina"] = pagina
                else:
                    entrada["subs"][f"{base}-{sub}"] = {"pagina": pagina}
            else:
                indice[tipo][clave]["pagina"] = pagina
        elif clave.startswith("tab") or clave.startswith("cap"):
            tipo = "tablas"
            match = re.match(r'(tab\d+)(?:-(.*))?', clave)
            if match:
                base = match.group(1)
                sub = match.group(2)
                entrada = indice[tipo][base]
                if sub is None:
                    entrada["pagina"] = pagina
                else:
                    entrada["subs"][f"{base}-{sub}"] = {"pagina": pagina}
            else:
                indice[tipo][clave]["pagina"] = pagina
    for tipo in indice:
        indice[tipo] = dict(indice[tipo])
    return indice


@lru_cache(maxsize=1)
def _obtener_indice():
    return _construir_indice_jerarquico(MAPA)


def _filtrar_indice(indice: dict, texto: str) -> dict:
    if not texto:
        return indice
    texto = texto.lower()
    filtrado = {"articulos": {}, "tablas": {}}
    for tipo in ["articulos", "tablas"]:
        for base, info in indice[tipo].items():
            base_match = texto in base.lower()
            subs_filtrados = {}
            for subclave, subinfo in info["subs"].items():
                if texto in subclave.lower() or base_match:
                    subs_filtrados[subclave] = subinfo
            if base_match or subs_filtrados:
                filtrado[tipo][base] = {"pagina": info["pagina"], "subs": subs_filtrados}
    return filtrado


