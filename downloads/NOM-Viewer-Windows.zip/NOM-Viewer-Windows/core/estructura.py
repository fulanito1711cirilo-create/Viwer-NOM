"""Segmentación reproducible de encabezados; no interpreta requisitos técnicos."""
from bisect import bisect_right
from collections import Counter
import re

ARTICULO = re.compile(r'^[ \t]*ART[ÍI]CULO[ \t]+(\d+)[ \t]*$', re.MULTILINE)
CAPITULO = re.compile(r'^[ \t]*CAP[ÍI]TULO[ \t]+(\d+)[ \t]*$', re.MULTILINE)
SECCION = re.compile(r'^[ \t]*(\d+-\d+)\.[ \t]+([^\n]+)', re.MULTILINE)


def segmentar(paginas, evidencias=None):
    inicios = []
    total = 0
    eventos = []
    for pagina, texto in enumerate(paginas):
        inicios.append(total)
        for patron, tipo in [(ARTICULO, 'articulo'), (SECCION, 'seccion'), (CAPITULO, 'capitulo')]:
            for match in patron.finditer(texto):
                clave = ('cap' if tipo == 'capitulo' else 'art') + match[1]
                eventos.append({'clave':clave, 'tipo':tipo, 'posicion':total + match.start(),
                                'titulo':match[0].strip(), 'pagina':pagina})
        total += len(texto)
    eventos.sort(key=lambda e:e['posicion'])
    descartados = []
    if evidencias is not None:
        aceptados = []
        activo = None
        for evento in eventos:
            if evento['tipo'] == 'capitulo':
                activo = None
                aceptados.append(evento)
                continue
            if evento['tipo'] == 'articulo':
                activo = evento['clave']
                aceptados.append(evento)
                continue
            candidatos = [e for e in evidencias.get(evento['pagina'], [])
                           if evento['titulo'].startswith(e['texto'].strip())]
            evidencia = max(candidatos, key=lambda e:len(e['texto']), default=None)
            razon = None
            if evidencia and not evidencia['negrita']:
                razon = 'cita_en_texto_normal'
            elif evento['clave'].split('-')[0] != activo:
                razon = 'cita_fuera_del_articulo_activo'
            if razon:
                descartados.append({**evento, 'razon':razon, 'evidencia':evidencia})
            else:
                evento['evidencia_tipografica'] = evidencia
                aceptados.append(evento)
        eventos = aceptados
    conteos = Counter(e['clave'] for e in eventos if e['tipo'] != 'capitulo')
    unidades = []
    documento = ''.join(paginas)
    articulos = {e['clave'] for e in eventos if e['tipo'] == 'articulo'}
    articulo_activo = None
    for i, evento in enumerate(eventos):
        if evento['tipo'] == 'capitulo':
            articulo_activo = None
            continue
        # Un artículo abarca sus secciones; una sección termina en el siguiente encabezado.
        siguientes = eventos[i+1:]
        if evento['tipo'] == 'articulo':
            siguiente = next((e for e in siguientes if e['tipo'] in ('articulo', 'capitulo')), None)
            padre = None
            articulo_activo = evento['clave']
        else:
            siguiente = siguientes[0] if siguientes else None
            padre = evento['clave'].split('-')[0]
        fin = siguiente['posicion'] if siguiente else total
        motivo = []
        if conteos[evento['clave']] != 1:
            motivo.append('encabezado_repetido')
        if padre and padre not in articulos:
            motivo.append('articulo_padre_no_localizado')
        if padre and padre != articulo_activo:
            motivo.append('encabezado_fuera_de_su_articulo')
        if siguiente is None:
            motivo.append('limite_final_no_confirmado')
        fin_pagina = max(0, bisect_right(inicios, max(evento['posicion'], fin - 1)) - 1)
        if siguiente and conteos[siguiente['clave']] > 1:
            motivo.append('limite_siguiente_ambiguo')
        subdivisiones = []
        if evento['tipo'] == 'seccion':
            segmento = documento[evento['posicion']:fin]
            letra = None
            for marca in re.finditer(r'^[ \t]*([a-z]|\d+)\)[ \t]+([^\n]+)|^[ \t]*(EXCEPCI[ÓO]N[^:\n]*|Excepci[óo]n[^:\n]*|NOTA[^:\n]*)[.:]', segmento, re.MULTILINE):
                posicion = evento['posicion'] + marca.start()
                pagina_marca = max(0, bisect_right(inicios, posicion) - 1)
                etiqueta = marca[1] or marca[3]
                if marca[1] and marca[1].isalpha():
                    letra = marca[1]
                subdivisiones.append({'etiqueta':etiqueta, 'titulo':marca[0].strip(),
                                      'tipo':'inciso_candidato' if marca[1] else 'nota_o_excepcion',
                                      'inciso_letra':letra, 'desplazamiento':marca.start(),
                                      'pagina_pdf':pagina_marca + 1,
                                      'offset_pagina':posicion - inicios[pagina_marca],
                                      'revision_humana':False})
        unidades.append({**evento, 'padre':padre, 'inicio':evento['posicion'], 'fin':fin,
                         'pagina_fin':fin_pagina, 'offset_inicio':evento['posicion'] - inicios[evento['pagina']],
                         'estado':'requiere_revision' if motivo else 'delimitada_automaticamente',
                         'motivos':motivo, 'subdivisiones':subdivisiones, 'revision_humana':False})
    reporte = {'version_esquema':3, 'paginas':len(paginas), 'unidades':len(unidades),
               'articulos':sum(u['tipo']=='articulo' for u in unidades),
               'secciones':sum(u['tipo']=='seccion' for u in unidades),
               'claves_repetidas':sorted(k for k,v in conteos.items() if v > 1),
               'requieren_revision':sum(bool(u['motivos']) for u in unidades),
               'candidatos_descartados':descartados,
               'revision_humana':False}
    return unidades, reporte
