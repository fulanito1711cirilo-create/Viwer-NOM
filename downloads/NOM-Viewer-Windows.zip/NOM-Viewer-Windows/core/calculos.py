"""
core/calculos.py
================
Módulo de lógica de negocio para cálculos eléctricos basados en NOM-001-SEDE-2012.

Sin dependencias de UI. Sin efectos secundarios. Testeable de forma aislada.
Cada función recibe parámetros tipados y devuelve un dict estructurado con:
  - resultado(s) numérico(s)
  - unidad
  - cumple: bool o None si no aplica
  - articulos_citados: list[str]
  - detalle: str con el desarrollo del cálculo
  - advertencias: list[str] para condiciones límite
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Optional
from functools import wraps
import inspect
from core.version import MOTOR_VERSION
from core.tablas import TABLAS, fuente, factor_temperatura_75, factor_agrupamiento

# ==============================================================================
# CONSTANTES TÉCNICAS
# ==============================================================================

# Columnas de 75 °C de la Tabla 310-15(b)(16), transcritas del PDF.
AMPACIDADES_COBRE_75 = TABLAS['tab310-15b16']['cobre']
AMPACIDADES_ALUMINIO_75 = TABLAS['tab310-15b16']['aluminio']

# R y X de la Tabla 9, columnas separadas por material y conduit.
TABLA_9 = TABLAS['tab9']['cobre']

# Calibres en orden ascendente de capacidad
CALIBRES_ORDENADOS: list[str] = [
    "14", "12", "10", "8", "6", "4", "3", "2", "1",
    "1/0", "2/0", "3/0", "4/0",
    "250", "300", "350", "400", "500", "600", "750", "1000",
]

# Valores comerciales de ITM según Art. 240-6
VALORES_ITM: list[int] = [
    15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80, 90, 100,
    110, 125, 150, 175, 200, 225, 250, 300, 350, 400, 450,
    500, 600, 700, 800, 1000, 1200, 1600, 2000,
]

# Capacidades interruptivas comerciales en kA
KAIC_COMERCIALES: list[int] = [10, 14, 22, 25, 35, 42, 65, 100, 150, 200]

# Factores de demanda por tipo de inmueble (referencia Art. 220)
FACTORES_DEMANDA: dict[str, float] = {
    "Vivienda unifamiliar": 0.35,
    "Departamento":         0.38,
    "Oficina":              0.75,
    "Local comercial":      0.80,
    "Industria ligera":     0.70,
    "Industria pesada":     0.85,
    "Hospital":             0.80,
    "Escuela":              0.75,
    "Almacén":              0.60,
}

# Potencias comerciales de transformadores en kVA
POTENCIAS_TRANSFORMADOR_STD: list[float] = [
    15, 30, 45, 75, 112.5, 150, 225, 300, 500,
    750, 1000, 1250, 1500, 2000, 2500,
]


# ==============================================================================
# DATACLASS DE RESULTADO
# ==============================================================================

@dataclass
class ResultadoCalculo:
    """
    Resultado estructurado de cualquier cálculo del módulo.
    Viaja de core/ → services/ → ui/ sin pérdida de información.
    """
    tipo: str                                    # identificador del cálculo
    valores: dict[str, float | str]             # resultados numéricos clave
    unidades: dict[str, str]                    # unidad de cada valor
    cumple: Optional[bool]                      # None si no hay límite normativo
    limite_normativo: Optional[str]             # descripción del límite
    articulos_citados: list[str] = field(default_factory=list)
    detalle: str = ""                           # desarrollo paso a paso
    advertencias: list[str] = field(default_factory=list)
    fuentes: list[dict] = field(default_factory=list)
    revision_profesional: bool = False
    entradas: dict = field(default_factory=dict)
    funcion: str = ''
    motor_version: str = MOTOR_VERSION


def registrar_entradas(funcion):
    firma = inspect.signature(funcion)

    @wraps(funcion)
    def ejecutar(*args, **kwargs):
        parametros = firma.bind(*args, **kwargs)
        parametros.apply_defaults()
        resultado = funcion(*args, **kwargs)
        resultado.entradas = dict(parametros.arguments)
        resultado.funcion = funcion.__name__
        return resultado
    return ejecutar


# ==============================================================================
# FUNCIONES AUXILIARES INTERNAS
# ==============================================================================

def _validar_positivo(valor: float, nombre: str) -> None:
    """Lanza ValueError si el valor no es mayor que cero."""
    if not math.isfinite(valor) or valor <= 0:
        raise ValueError(f"'{nombre}' debe ser mayor que cero. Recibido: {valor}")


def _validar_rango(valor: float, minimo: float, maximo: float, nombre: str) -> None:
    """Lanza ValueError si el valor está fuera del rango válido."""
    if not (minimo <= valor <= maximo):
        raise ValueError(
            f"'{nombre}' debe estar entre {minimo} y {maximo}. Recibido: {valor}"
        )


def _obtener_rx(material: str, conduit: str, calibre: str) -> tuple[float, float]:
    """
    Devuelve (R, X) en Ω/km para el calibre y conduit dados.
    Usa columnas independientes de cobre y aluminio; no aproxima un material a partir del otro.

    Args:
        material: "cobre" | "aluminio"
        conduit:  "PVC" | "Aluminio" | "Acero"
        calibre:  AWG o kcmil como string

    Returns:
        Tupla (R, X) en Ω/km

    Raises:
        ValueError: si el calibre o conduit no existe en la Tabla 9
    """
    if material not in ('cobre', 'aluminio'):
        raise ValueError('Material debe ser cobre o aluminio.')
    tabla = TABLAS['tab9'][material]
    if calibre not in tabla:
        raise ValueError(f'No hay valores tabulados de {material} para calibre {calibre}.')
    if conduit not in tabla[calibre]:
        raise ValueError('Conduit debe ser PVC, Aluminio o Acero.')
    datos = tabla[calibre][conduit]
    return datos['R'], datos['X']


def _factor_temperatura(temp_ambiente: float) -> float:
    """
    Devuelve el factor de corrección por temperatura para conductores a 75°C.
    Tabla 310-15(b)(2)(a), base ambiente de 30 °C.

    Args:
        temp_ambiente: temperatura ambiente en °C

    Returns:
        Factor FT (multiplicador sobre ampacidad base)
    """
    return factor_temperatura_75(temp_ambiente)


def _factor_agrupamiento(num_conductores: int) -> float:
    """
    Devuelve el factor de ajuste por agrupamiento de conductores.
    Tabla 310-15(b)(3)(a).

    Args:
        num_conductores: número de conductores portadores de corriente en la canalización

    Returns:
        Factor FA (multiplicador sobre ampacidad base)
    """
    return factor_agrupamiento(num_conductores)


def _siguiente_itm(corriente_minima: float) -> Optional[int]:
    """
    Devuelve el siguiente valor comercial de ITM ≥ corriente_minima.
    Art. 240-6.

    Returns:
        Valor en amperios o None si supera el máximo disponible.
    """
    return next((v for v in VALORES_ITM if v >= corriente_minima), None)


def _siguiente_kaic(icc_ka: float) -> int:
    """
    Devuelve la capacidad interruptiva comercial mínima ≥ icc_ka.
    Si supera todos los valores disponibles, rechaza la selección.
    """
    _validar_positivo(icc_ka, 'icc_ka')
    valor = next((k for k in KAIC_COMERCIALES if k >= icc_ka), None)
    if valor is None:
        raise ValueError('La corriente de cortocircuito supera las capacidades interruptivas disponibles.')
    return valor


# ==============================================================================
# 1. CAÍDA DE TENSIÓN
# ==============================================================================

@registrar_entradas
def calcular_caida_tension(
    tipo_circuito: str,
    material: str,
    conduit: str,
    calibre: str,
    longitud_m: float,
    corriente_a: float,
    voltaje_v: float,
    factor_potencia: float,
    conductores_por_fase: int = 1,
) -> ResultadoCalculo:
    """
    Calcula la caída de tensión según la Tabla 9 de la NOM-001-SEDE-2012.

    Fórmula: e = k × (I / Cf) × L[km] × (R × cos φ + X × sin φ)
    Donde k = √3 para trifásico, k = 2 para monofásico.

    Args:
        tipo_circuito:       "Trifásico" | "Monofásico 2 hilos" | "Monofásico 3 hilos"
        material:            "cobre" | "aluminio"
        conduit:             "PVC" | "Aluminio" | "Acero"
        calibre:             AWG o kcmil como string (ej: "10", "1/0", "250")
        longitud_m:          Longitud del circuito en metros
        corriente_a:         Corriente de carga en amperios
        voltaje_v:           Voltaje línea-línea en voltios
        factor_potencia:     cos φ (0.01 a 1.0)
        conductores_por_fase: Número de conductores en paralelo por fase (default 1)

    Returns:
        ResultadoCalculo con caida_v, caida_pct, R, X y evaluación normativa.

    Raises:
        ValueError: si algún parámetro está fuera de rango o es inválido.
    """
    # --- Validaciones ---
    _validar_positivo(longitud_m, "longitud_m")
    _validar_positivo(corriente_a, "corriente_a")
    _validar_positivo(voltaje_v, "voltaje_v")
    _validar_rango(factor_potencia, 0.01, 1.0, "factor_potencia")
    if isinstance(conductores_por_fase, bool) or not isinstance(conductores_por_fase, int) or conductores_por_fase < 1:
        raise ValueError("'conductores_por_fase' debe ser al menos 1.")
    if tipo_circuito not in ("Trifásico", "Monofásico 2 hilos", "Monofásico 3 hilos"):
        raise ValueError(f"tipo_circuito '{tipo_circuito}' no reconocido.")

    # --- Parámetros de cálculo ---
    R, X = _obtener_rx(material, conduit, calibre)
    cos_phi = factor_potencia
    sin_phi = math.sqrt(max(0.0, 1.0 - cos_phi ** 2))
    I_conductor = corriente_a / conductores_por_fase
    L_km = longitud_m / 1000.0
    k = math.sqrt(3) if tipo_circuito == "Trifásico" else 2.0

    # --- Cálculo principal ---
    caida_v = k * I_conductor * L_km * (R * cos_phi + X * sin_phi)
    caida_pct = (caida_v / voltaje_v) * 100.0

    # --- Evaluación normativa ---
    # Art. 210-19(a)(1): ≤ 3% en circuito derivado
    # Art. 215-2(a)(3):  ≤ 5% acumulado (alimentador + circuito)
    limite_3 = caida_pct <= 3.0
    limite_5 = caida_pct <= 5.0
    cumple = limite_3

    advertencias: list[str] = ['R y X tabulados a 75 °C, 60 Hz y tres conductores en conduit. Verificar aplicabilidad a la configuración real.']
    if not limite_3 and limite_5:
        advertencias.append(
            f"Caída ({caida_pct:.2f}%) excede el 3% del circuito derivado. "
            "Verificar que la caída acumulada (alimentador + circuito) no supere el 5%."
        )
    if not limite_5:
        advertencias.append(
            f"Caída ({caida_pct:.2f}%) excede el 5% total de referencia. "
            "Revisar el diseño y el criterio de caída aplicable."
        )

    detalle = (
        f"k={k:.4f} | I_cond={I_conductor:.3f} A | L={L_km:.4f} km\n"
        f"R={R:.4f} Ω/km | X={X:.4f} Ω/km\n"
        f"cos φ={cos_phi:.3f} | sin φ={sin_phi:.3f}\n"
        f"e = {k:.4f} × {I_conductor:.3f} × {L_km:.4f} × "
        f"({R:.4f}×{cos_phi:.3f} + {X:.4f}×{sin_phi:.3f})\n"
        f"e = {caida_v:.4f} V → {caida_pct:.3f}%"
    )

    return ResultadoCalculo(
        tipo="caida_tension",
        valores={
            "caida_v": round(caida_v, 4),
            "caida_pct": round(caida_pct, 3),
            "R_ohm_km": R,
            "X_ohm_km": X,
            "k": round(k, 4),
            "I_conductor_a": round(I_conductor, 3),
        },
        unidades={
            "caida_v": "V",
            "caida_pct": "%",
            "R_ohm_km": "Ω/km",
            "X_ohm_km": "Ω/km",
            "k": "—",
            "I_conductor_a": "A",
        },
        cumple=cumple,
        limite_normativo="Referencia de diseño: 3% circuito derivado y 5% total; revisar notas de 210-19 y 215-2",
        articulos_citados=["art210-19", "art215-2", "tab9"],
        detalle=detalle,
        advertencias=advertencias,
        fuentes=[fuente("tab9")],
    )


# ==============================================================================
# 2. SELECCIÓN DE CALIBRE
# ==============================================================================

@registrar_entradas
def seleccionar_calibre(
    corriente_carga_a: float,
    longitud_m: float,
    voltaje_v: float,
    tipo_circuito: str,
    material: str,
    conduit: str,
    temp_ambiente_c: float = 30.0,
    num_conductores_canaliz: int = 3,
    factor_potencia: float = 0.85,
    caida_max_pct: float = 3.0,
    conductores_por_fase: int = 1,
) -> ResultadoCalculo:
    """
    Selecciona el calibre mínimo que satisface simultáneamente:
    1. Ampacidad corregida ≥ corriente de carga (Tabla 310-15(b)(16))
    2. Caída de tensión ≤ caida_max_pct (Tabla 9)

    El calibre final es el mayor de los dos requerimientos.

    Args:
        corriente_carga_a:      Corriente de diseño en amperios
        longitud_m:             Longitud del circuito en metros
        voltaje_v:              Voltaje línea-línea en voltios
        tipo_circuito:          "Trifásico" | "Monofásico 2 hilos" | "Monofásico 3 hilos"
        material:               "cobre" | "aluminio"
        conduit:                "PVC" | "Aluminio" | "Acero"
        temp_ambiente_c:        Temperatura ambiente en °C (default 30)
        num_conductores_canaliz: Conductores portadores en la canalización (default 3)
        factor_potencia:        cos φ (default 0.85)
        caida_max_pct:          Límite de caída de tensión en % (default 3.0)
        conductores_por_fase:   Conductores en paralelo por fase (default 1)

    Returns:
        ResultadoCalculo con:
            calibre_ampacidad: calibre mínimo por corriente
            calibre_caida:     calibre mínimo por caída de tensión
            calibre_final:     el mayor de los dos (el que se instala)
            ampacidad_corregida: capacidad real del calibre final
            caida_pct_final:   caída real con el calibre final

    Raises:
        ValueError: si ningún calibre estándar satisface los requerimientos.
    """
    # --- Validaciones ---
    _validar_positivo(corriente_carga_a, "corriente_carga_a")
    _validar_positivo(longitud_m, "longitud_m")
    _validar_positivo(voltaje_v, "voltaje_v")
    _validar_rango(factor_potencia, 0.01, 1.0, "factor_potencia")
    _validar_rango(caida_max_pct, 0.1, 10.0, "caida_max_pct")

    FT = _factor_temperatura(temp_ambiente_c)
    FA = _factor_agrupamiento(num_conductores_canaliz)
    factor_correccion = FT * FA

    # --- Paso 1: Calibre mínimo por ampacidad ---
    if material not in ('cobre','aluminio'):
        raise ValueError('Material debe ser cobre o aluminio.')
    if isinstance(conductores_por_fase, bool) or not isinstance(conductores_por_fase, int) or conductores_por_fase < 1:
        raise ValueError('Conductores por fase debe ser un entero positivo.')
    ampacidades = AMPACIDADES_COBRE_75 if material == 'cobre' else AMPACIDADES_ALUMINIO_75

    corriente_requerida = corriente_carga_a / (factor_correccion * conductores_por_fase)
    calibre_por_ampacidad: Optional[str] = None
    for cal in CALIBRES_ORDENADOS:
        if cal not in ampacidades:
            continue
        if conductores_por_fase > 1 and CALIBRES_ORDENADOS.index(cal) < CALIBRES_ORDENADOS.index('1/0'):
            continue
        if ampacidades[cal] >= corriente_requerida:
            calibre_por_ampacidad = cal
            break

    if calibre_por_ampacidad is None:
        raise ValueError(
            f"Ningún calibre estándar soporta {corriente_requerida:.1f} A "
            f"(corriente requerida con FT={FT:.2f}, FA={FA:.2f}). "
            "Considere conductores en paralelo por fase."
        )

    # --- Paso 2: Calibre mínimo por caída de tensión ---
    idx_inicio = CALIBRES_ORDENADOS.index(calibre_por_ampacidad)
    calibre_por_caida: Optional[str] = None
    caida_final_pct: float = 0.0

    for cal in CALIBRES_ORDENADOS[idx_inicio:]:
        try:
            resultado_caida = calcular_caida_tension(
                tipo_circuito=tipo_circuito,
                material=material,
                conduit=conduit,
                calibre=cal,
                longitud_m=longitud_m,
                corriente_a=corriente_carga_a,
                voltaje_v=voltaje_v,
                factor_potencia=factor_potencia,
                conductores_por_fase=conductores_por_fase,
            )
            caida_pct = resultado_caida.valores["caida_pct"]
            if caida_pct <= caida_max_pct:
                calibre_por_caida = cal
                caida_final_pct = caida_pct
                break
        except ValueError:
            continue

    if calibre_por_caida is None:
        raise ValueError(
            f"Ningún calibre estándar cumple la caída máxima de {caida_max_pct}% "
            f"para {corriente_carga_a} A en {longitud_m} m. "
            "Considere aumentar voltaje o usar conductores en paralelo."
        )

    # --- Paso 3: Calibre final (el más restrictivo) ---
    idx_amp = CALIBRES_ORDENADOS.index(calibre_por_ampacidad)
    idx_cai = CALIBRES_ORDENADOS.index(calibre_por_caida)
    calibre_final = CALIBRES_ORDENADOS[max(idx_amp, idx_cai)]

    ampacidad_base = ampacidades[calibre_final]
    ampacidad_corregida = ampacidad_base * factor_correccion * conductores_por_fase

    advertencias: list[str] = [
        'Selección a 75 °C y base ambiente 30 °C. Verificar temperatura de terminales, aislamiento, protección de conductores pequeños y condiciones de instalación.',
        'Tabla 9: comprobar configuración física y condiciones de sus notas; el resultado no constituye certificación.',
    ]
    if conductores_por_fase > 1:
        advertencias.append('Paralelos desde 1/0 AWG: comprobar requisitos completos de 310-10(h) e incluir todos los portadores en el conteo de agrupamiento.')
    if calibre_por_caida != calibre_por_ampacidad:
        advertencias.append(
            f"La caída de tensión exige un calibre mayor ({calibre_por_caida}) "
            f"que el requerido por ampacidad ({calibre_por_ampacidad})."
        )
    if FT < 1.0:
        advertencias.append(
            f"Factor temperatura {FT:.2f} aplicado para {temp_ambiente_c}°C. "
            "Ampacidad reducida respecto a tabla base."
        )
    if FA < 1.0:
        advertencias.append(
            f"Factor agrupamiento {FA:.2f} aplicado para {num_conductores_canaliz} "
            "conductores en canalización."
        )

    detalle = (
        f"FT (temp {temp_ambiente_c}°C) = {FT:.2f} | "
        f"FA ({num_conductores_canaliz} cond.) = {FA:.2f}\n"
        f"Corriente requerida = {corriente_carga_a:.1f} / ({factor_correccion:.2f} × {conductores_por_fase}) "
        f"= {corriente_requerida:.1f} A\n"
        f"Calibre por ampacidad: {calibre_por_ampacidad} "
        f"({ampacidades[calibre_por_ampacidad]} A base)\n"
        f"Calibre por caída ({caida_max_pct}%): {calibre_por_caida} "
        f"(caída = {caida_final_pct:.2f}%)\n"
        f"Calibre final instalado: {calibre_final} "
        f"(ampacidad corregida = {ampacidad_corregida:.1f} A)"
    )

    return ResultadoCalculo(
        tipo="seleccion_calibre",
        valores={
            "calibre_ampacidad": calibre_por_ampacidad,
            "calibre_caida": calibre_por_caida,
            "calibre_final": calibre_final,
            "ampacidad_base_a": float(ampacidad_base),
            "ampacidad_corregida_a": round(ampacidad_corregida, 2),
            "FT": FT,
            "FA": FA,
            "corriente_requerida_a": round(corriente_requerida, 2),
            "caida_pct_final": round(caida_final_pct, 3),
        },
        unidades={
            "calibre_final": "AWG/kcmil",
            "ampacidad_corregida_a": "A",
            "corriente_requerida_a": "A",
            "caida_pct_final": "%",
            "FT": "—",
            "FA": "—",
        },
        cumple=True,
        limite_normativo=(
            f"Ampacidad ≥ corriente de carga | Caída ≤ {caida_max_pct}% "
            "(Art. 310, Tabla 310-15(b)(16), Art. 210-19)"
        ),
        articulos_citados=["art310", "tab310-15b16", "tab310-15b2a", "tab310-15b3a", "art210-19"],
        detalle=detalle,
        advertencias=advertencias,
        fuentes=[fuente(k) for k in ("tab310-15b16", "tab310-15b2a", "tab310-15b3a", "tab9")],
    )


# ==============================================================================
# 3. CÁLCULO DE CARGAS
# ==============================================================================

@registrar_entradas
def calcular_cargas(
    tipo_inmueble: str,
    area_m2: float,
    carga_calefaccion_w: float = 0.0,
    carga_agua_w: float = 0.0,
    carga_estufa_w: float = 0.0,
    carga_motores_w: float = 0.0,
    carga_aire_w: float = 0.0,
    carga_otros_w: float = 0.0,
    voltaje_v: float = 220.0,
    factor_potencia: float = 0.90,
    factor_demanda_override: Optional[float] = None,
) -> ResultadoCalculo:
    """
    Calcula la carga total y demanda máxima según Art. 220 de la NOM-001-SEDE-2012.

    Proceso:
      1. Alumbrado: área × 33 VA/m² (Art. 220-12)
      2. Contactos: estimación por área, 180 VA/salida (Art. 220-14)
      3. Circuitos especiales vivienda: 2 × 1500 VA + 1500 VA lavandería (Art. 220-52)
      4. Cargas específicas (equipos fijos) a plena carga
      5. Demanda = carga_total × factor_demanda (Art. 220-42, 220-54, 220-55)
      6. Corriente estimada = demanda_va / (voltaje × fp)

    Args:
        tipo_inmueble:          Clave de FACTORES_DEMANDA (ej: "Vivienda unifamiliar")
        area_m2:                Superficie construida en m²
        carga_calefaccion_w:    Calefacción / HVAC en W
        carga_agua_w:           Calentador de agua en W
        carga_estufa_w:         Estufa/horno en W
        carga_motores_w:        Motores (suma total) en W
        carga_aire_w:           Aire acondicionado en W
        carga_otros_w:          Otros equipos especiales en W
        voltaje_v:              Voltaje para estimación de corriente (default 220 V)
        factor_potencia:        cos φ para conversión VA → A (default 0.90)
        factor_demanda_override: Si se provee, sobreescribe el factor de FACTORES_DEMANDA

    Returns:
        ResultadoCalculo con desglose completo de cargas y corriente estimada.

    Raises:
        ValueError: si tipo_inmueble no está registrado y no se provee override.
    """
    # --- Validaciones ---
    _validar_positivo(area_m2, "area_m2")
    _validar_positivo(voltaje_v, "voltaje_v")
    _validar_rango(factor_potencia, 0.01, 1.0, "factor_potencia")

    es_vivienda = tipo_inmueble in ("Vivienda unifamiliar", "Departamento")

    if factor_demanda_override is not None:
        _validar_rango(factor_demanda_override, 0.01, 1.0, "factor_demanda_override")
        fd = factor_demanda_override
    elif tipo_inmueble in FACTORES_DEMANDA:
        fd = FACTORES_DEMANDA[tipo_inmueble]
    else:
        raise ValueError(
            f"tipo_inmueble '{tipo_inmueble}' no registrado. "
            f"Use factor_demanda_override o uno de: {list(FACTORES_DEMANDA.keys())}"
        )

    # --- Cálculo de cargas base ---
    # Art. 220-12: 33 VA/m² para viviendas, locales generales
    alumbrado_va = area_m2 * 33.0

    # Art. 220-14: 180 VA por salida. Estimación: 1 salida cada 30 m²
    num_contactos = max(2, int(area_m2 / 30))
    contactos_va = num_contactos * 180.0

    # Art. 220-52: circuitos especiales solo para viviendas
    # 2 circuitos pequeños aparatos × 1500 VA + 1 circuito lavandería × 1500 VA
    especiales_va = 4500.0 if es_vivienda else 0.0

    # Cargas fijas a plena potencia (sin factor de demanda individual)
    cargas_fijas_w = (
        carga_calefaccion_w
        + carga_agua_w
        + carga_estufa_w
        + carga_motores_w
        + carga_aire_w
        + carga_otros_w
    )

    # Para motores: 125% del motor mayor + 100% demás (simplificado: se aplica 125% al total)
    # El usuario debe pasar la carga correcta si hay motores identificados individualmente
    carga_total_va = alumbrado_va + contactos_va + especiales_va + cargas_fijas_w

    # --- Demanda máxima ---
    demanda_va = carga_total_va * fd
    demanda_kva = demanda_va / 1000.0

    # --- Corriente estimada ---
    corriente_estimada_a = demanda_va / (voltaje_v * factor_potencia)

    advertencias: list[str] = ['Estimación preliminar: las densidades y factores de demanda genéricos heredados no sustituyen el procedimiento aplicable al inmueble y sus cargas.']
    if carga_motores_w > 0:
        advertencias.append(
            "Para motores: verificar Art. 430 — aplicar 125% al motor de mayor potencia "
            "y 100% a los demás. El cálculo actual suma el total sin distinción."
        )
    if not es_vivienda and especiales_va == 0:
        advertencias.append(
            "Circuitos especiales de vivienda no aplicados. "
            "Verificar si el inmueble requiere circuitos dedicados adicionales (Art. 220-52)."
        )

    detalle = (
        f"Tipo: {tipo_inmueble} | Área: {area_m2} m²\n"
        f"Alumbrado (33 VA/m²): {alumbrado_va:,.1f} VA\n"
        f"Contactos ({num_contactos} × 180 VA): {contactos_va:,.1f} VA\n"
        f"Circuitos especiales vivienda: {especiales_va:,.1f} VA\n"
        f"Cargas fijas: {cargas_fijas_w:,.1f} W\n"
        f"Carga total sin FD: {carga_total_va:,.1f} VA\n"
        f"Factor de demanda ({tipo_inmueble}): {fd*100:.0f}%\n"
        f"Demanda máxima: {demanda_va:,.1f} VA = {demanda_kva:.2f} kVA\n"
        f"Corriente estimada ({voltaje_v}V, FP={factor_potencia}): {corriente_estimada_a:.1f} A"
    )

    return ResultadoCalculo(
        tipo="calculo_cargas",
        valores={
            "alumbrado_va": round(alumbrado_va, 1),
            "contactos_va": round(contactos_va, 1),
            "especiales_va": especiales_va,
            "cargas_fijas_w": round(cargas_fijas_w, 1),
            "carga_total_va": round(carga_total_va, 1),
            "factor_demanda": fd,
            "demanda_va": round(demanda_va, 1),
            "demanda_kva": round(demanda_kva, 3),
            "corriente_estimada_a": round(corriente_estimada_a, 2),
            "num_contactos": float(num_contactos),
        },
        unidades={
            "alumbrado_va": "VA",
            "contactos_va": "VA",
            "especiales_va": "VA",
            "cargas_fijas_w": "W",
            "carga_total_va": "VA",
            "factor_demanda": "—",
            "demanda_va": "VA",
            "demanda_kva": "kVA",
            "corriente_estimada_a": "A",
            "num_contactos": "uds",
        },
        cumple=None,
        limite_normativo=None,
        articulos_citados=["art220", "art220-12", "art220-14", "art220-52",
                           "tab220-42", "tab220-54", "tab220-55"],
        detalle=detalle,
        advertencias=advertencias,
    )


# ==============================================================================
# 4. SELECCIÓN DE PROTECCIONES
# ==============================================================================

@registrar_entradas
def seleccionar_proteccion(
    tipo_carga: str,
    corriente_carga_a: float,
    icc_disponible_ka: float,
    ampacidad_conductor_a: Optional[float] = None,
) -> ResultadoCalculo:
    """
    Selecciona el interruptor termomagnético (ITM) según Art. 240 y Art. 430.

    Criterios de selección:
      - Cargas generales continuas: In ≤ 1.25 × Ic (Art. 210-20, 215-3)
      - Motores:                    In ≤ 1.5 × Im  (Art. 430-52, Tabla 430-52)
      - Transformadores:            Coordinación según Art. 450-3

    También verifica coordinación con el conductor si se provee su ampacidad.

    Args:
        tipo_carga:             "General" | "Motor" | "Transformador"
        corriente_carga_a:      Corriente nominal de la carga en amperios
        icc_disponible_ka:      Corriente de cortocircuito disponible en kA
        ampacidad_conductor_a:  Ampacidad corregida del conductor (opcional).
                                Si se provee, verifica que In ≤ ampacidad_conductor.

    Returns:
        ResultadoCalculo con itm_a, kaic_ka y verificación de coordinación.

    Raises:
        ValueError: si tipo_carga no es válido o corrientes son inválidas.
    """
    _validar_positivo(corriente_carga_a, "corriente_carga_a")
    _validar_positivo(icc_disponible_ka, "icc_disponible_ka")

    tipos_validos = ("General", "Motor", "Transformador")
    if tipo_carga not in tipos_validos:
        raise ValueError(f"tipo_carga '{tipo_carga}' no válido. Use: {tipos_validos}")

    # --- Factor multiplicador según tipo ---
    if tipo_carga == "Motor":
        factor = 1.5
        criterio = "In ≤ 1.5 × Im (Art. 430-52, Tabla 430-52)"
        arts = ["art430-31", "art430-52", "art240-6"]
    elif tipo_carga == "Transformador":
        factor = 1.25
        criterio = "Protección primaria: In ≤ 1.25 × I_prim (Art. 450-3)"
        arts = ["art450-3", "art240", "art240-6"]
    else:
        factor = 1.25
        criterio = "In ≥ 1.25 × Ic como referencia para carga continua (Art. 210-20, 215-3)"
        arts = ["art240", "art240-6", "art210-19"]

    corriente_minima = corriente_carga_a * factor
    itm_a = _siguiente_itm(corriente_minima)
    kaic_ka = _siguiente_kaic(icc_disponible_ka)

    if itm_a is None:
        raise ValueError(
            f"No existe ITM estándar para {corriente_minima:.1f} A. "
            "Requiere una selección de protección fuera del catálogo implementado."
        )

    advertencias: list[str] = []
    if tipo_carga in ('Motor','Transformador'):
        advertencias.append('Selección preliminar heredada: faltan tipo de dispositivo y condiciones completas de 430-52 o 450-3. No se determina conformidad normativa.')

    # Verificación de coordinación con el conductor
    coordinacion_ok: Optional[bool] = None
    if ampacidad_conductor_a is not None:
        _validar_positivo(ampacidad_conductor_a, "ampacidad_conductor_a")
        coordinacion_ok = itm_a <= ampacidad_conductor_a
        if not coordinacion_ok:
            advertencias.append(
                f"El ITM seleccionado ({itm_a} A) supera la ampacidad del conductor "
                f"({ampacidad_conductor_a:.1f} A). Aumentar calibre del conductor "
                "o reducir el ITM. Art. 240-4."
            )
            arts.append("art240")

    detalle = (
        f"Tipo de carga: {tipo_carga}\n"
        f"Corriente de carga: {corriente_carga_a:.1f} A\n"
        f"Factor multiplicador: {factor}\n"
        f"Corriente mínima ITM: {corriente_carga_a:.1f} × {factor} = {corriente_minima:.1f} A\n"
        f"ITM seleccionado: {itm_a} A (siguiente valor comercial ≥ {corriente_minima:.1f} A)\n"
        f"kAIC requerido: {icc_disponible_ka:.1f} kA → seleccionado: {kaic_ka} kA\n"
        f"Criterio: {criterio}"
    )
    if ampacidad_conductor_a:
        detalle += f"\nCoordinación con conductor ({ampacidad_conductor_a:.1f} A): "
        detalle += "✓ OK" if coordinacion_ok else "✗ FALLA — revisar"

    return ResultadoCalculo(
        tipo="seleccion_proteccion",
        valores={
            "itm_a": float(itm_a),
            "kaic_ka": float(kaic_ka),
            "factor_multiplicador": factor,
            "corriente_minima_itm_a": round(corriente_minima, 2),
            "coordinacion_conductor": float(coordinacion_ok) if coordinacion_ok is not None else -1.0,
        },
        unidades={
            "itm_a": "A",
            "kaic_ka": "kA",
            "corriente_minima_itm_a": "A",
        },
        cumple=coordinacion_ok if tipo_carga == 'General' else None,
        limite_normativo=criterio,
        articulos_citados=arts,
        detalle=detalle,
        advertencias=advertencias,
    )


# ==============================================================================
# 5. DIMENSIONAMIENTO DE TRANSFORMADOR
# ==============================================================================

@registrar_entradas
def dimensionar_transformador(
    carga_demandada_kva: float,
    voltaje_primario_v: float,
    voltaje_secundario_v: float,
    sistema: str,
    factor_crecimiento: float = 0.20,
) -> ResultadoCalculo:
    """
    Dimensiona el transformador y calcula corrientes nominales de primario y secundario.

    Selección de potencia comercial: siguiente estándar ≥ carga_demandada × (1 + factor_crecimiento).

    Args:
        carga_demandada_kva:  Carga demandada total en kVA
        voltaje_primario_v:   Tensión del lado de alta (V)
        voltaje_secundario_v: Tensión del lado de baja (V)
        sistema:              "Trifásico" | "Monofásico"
        factor_crecimiento:   Margen de reserva (default 0.20 = 20%)

    Returns:
        ResultadoCalculo con potencia seleccionada, corrientes y protecciones.

    Raises:
        ValueError: si la carga supera la mayor potencia estándar disponible.
    """
    _validar_positivo(carga_demandada_kva, "carga_demandada_kva")
    _validar_positivo(voltaje_primario_v, "voltaje_primario_v")
    _validar_positivo(voltaje_secundario_v, "voltaje_secundario_v")
    _validar_rango(factor_crecimiento, 0.0, 2.0, "factor_crecimiento")

    if sistema not in ("Trifásico", "Monofásico"):
        raise ValueError(f"sistema '{sistema}' no válido. Use: Trifásico, Monofásico.")

    carga_con_reserva = carga_demandada_kva * (1.0 + factor_crecimiento)
    potencia_std = next(
        (p for p in POTENCIAS_TRANSFORMADOR_STD if p >= carga_con_reserva), None
    )

    if potencia_std is None:
        raise ValueError(
            f"La carga requerida ({carga_con_reserva:.1f} kVA) supera la mayor potencia "
            f"estándar ({POTENCIAS_TRANSFORMADOR_STD[-1]} kVA). "
            "Considere dos transformadores en paralelo."
        )

    sqrt3 = math.sqrt(3)
    if sistema == "Trifásico":
        I_prim = (potencia_std * 1000.0) / (sqrt3 * voltaje_primario_v)
        I_sec = (potencia_std * 1000.0) / (sqrt3 * voltaje_secundario_v)
    else:
        I_prim = (potencia_std * 1000.0) / voltaje_primario_v
        I_sec = (potencia_std * 1000.0) / voltaje_secundario_v

    # Protección primaria máxima: Art. 450-3 — no mayor al 125% de I_prim para ≥ 9A
    prot_primaria_max = I_prim * 1.25
    itm_primario = _siguiente_itm(prot_primaria_max)

    advertencias: list[str] = ['La referencia al 125% no determina la protección admisible sin las condiciones completas de 450-3.']
    if potencia_std > carga_con_reserva * 1.5:
        advertencias.append(
            f"El transformador seleccionado ({potencia_std} kVA) supera en más del 50% "
            f"la carga requerida ({carga_con_reserva:.1f} kVA). "
            "Verificar si es el tamaño estándar inmediatamente superior disponible."
        )

    detalle = (
        f"Carga demandada: {carga_demandada_kva:.1f} kVA\n"
        f"Factor de crecimiento: {factor_crecimiento*100:.0f}%\n"
        f"Carga con reserva: {carga_con_reserva:.1f} kVA\n"
        f"Potencia comercial seleccionada: {potencia_std} kVA\n"
        f"Sistema: {sistema}\n"
        f"Corriente primario ({voltaje_primario_v} V): {I_prim:.2f} A\n"
        f"Corriente secundario ({voltaje_secundario_v} V): {I_sec:.2f} A\n"
        f"Referencia preliminar al 125% (no protección máxima): {prot_primaria_max:.1f} A → ITM: {itm_primario} A"
    )

    return ResultadoCalculo(
        tipo="transformador",
        valores={
            "potencia_kva": potencia_std,
            "carga_con_reserva_kva": round(carga_con_reserva, 2),
            "I_primario_a": round(I_prim, 2),
            "I_secundario_a": round(I_sec, 2),
            "referencia_125_primario_a": round(prot_primaria_max, 2),
            "itm_primario_referencia_a": float(itm_primario) if itm_primario else 0.0,
        },
        unidades={
            "potencia_kva": "kVA",
            "carga_con_reserva_kva": "kVA",
            "I_primario_a": "A",
            "I_secundario_a": "A",
            "referencia_125_primario_a": "A",
            "itm_primario_referencia_a": "A",
        },
        cumple=None,
        limite_normativo="Art. 450 — Transformadores | Art. 450-3 — Protección primaria",
        articulos_citados=["art450", "art450-3", "art240", "art240-6"],
        detalle=detalle,
        advertencias=advertencias,
    )


# ==============================================================================
# 6. PUESTA A TIERRA
# ==============================================================================

@registrar_entradas
def calcular_puesta_tierra(
    voltaje_linea_neutro_v: float,
    resistencia_tierra_ohm: float,
    material_conductor: str,
    corriente_alimentador_a: Optional[float] = None,
    corriente_dispositivo_a: Optional[float] = None,
    configuracion_electrodos: str = 'no_especificada',
) -> ResultadoCalculo:
    """Consulta parcial de puesta a tierra. V/R es solo un cociente ilustrativo, no corriente de falla del sistema.

    El conductor de equipos se dimensiona únicamente cuando se proporciona la capacidad/ajuste
    del dispositivo de protección. La corriente de alimentador es un parámetro heredado que ya
    no se usa para dimensionar. El criterio de 25 ohms solo se aplica a la excepción de un solo
    electrodo de varilla/tubería/placa (250-53(a)(2)); no es límite universal de conformidad.
    configuracion_electrodos: no_especificada o unico_varilla_tuberia_placa.
    """
    from core.tablas import DATOS, dimensionar_tierra_equipos
    _validar_positivo(voltaje_linea_neutro_v,'voltaje_linea_neutro_v')
    _validar_positivo(resistencia_tierra_ohm,'resistencia_tierra_ohm')
    if material_conductor not in ('Cobre','Aluminio'):
        raise ValueError('Material debe ser Cobre o Aluminio.')
    if configuracion_electrodos not in ('no_especificada','unico_varilla_tuberia_placa'):
        raise ValueError('Configuración de electrodos no admitida.')
    advertencias=['No se evalúa la conformidad completa de la puesta a tierra con solo resistencia y tensión.']
    fuentes=[]
    calibre='No determinado: falta capacidad del dispositivo de protección'
    if corriente_dispositivo_a is not None:
        conductor=dimensionar_tierra_equipos(corriente_dispositivo_a,material_conductor)
        calibre=f"{conductor['calibre']} {conductor['unidad_calibre']}"
        fuentes.append(conductor['fuente'])
    if corriente_alimentador_a is not None:
        _validar_positivo(corriente_alimentador_a,'corriente_alimentador_a')
        advertencias.append('La corriente del alimentador no sustituye la capacidad o ajuste del dispositivo para la Tabla 250-122.')
    adicional=-1.0
    if configuracion_electrodos=='unico_varilla_tuberia_placa':
        adicional=float(resistencia_tierra_ohm>25)
        advertencias.append('250-53(a)(2): se debe complementar el electrodo único; la excepción permite omitir el adicional si su resistencia es de 25 ohms o menos. Revisar las demás condiciones.')
        fuentes.append({'referencia':'art250-53','pagina_pdf':134,'sha256':DATOS['sha256'],
                        'estado':DATOS['estado'],'revision_profesional':False})
    return ResultadoCalculo(
        tipo='puesta_tierra',
        valores={'resistencia_tierra_ohm':resistencia_tierra_ohm,
                 'cociente_v_r_a':round(voltaje_linea_neutro_v/resistencia_tierra_ohm,2),
                 'calibre_tierra_equipos':calibre,'requiere_electrodo_adicional':adicional,
                 'configuracion_electrodos':configuracion_electrodos},
        unidades={'resistencia_tierra_ohm':'ohm','cociente_v_r_a':'A'},cumple=None,
        limite_normativo='Consulta parcial: conductor de equipos 250-122 y excepción de electrodo único 250-53(a)(2).',
        articulos_citados=['art250-53','tab250-122'],
        detalle=f'Resistencia medida: {resistencia_tierra_ohm} ohm. V/R: {voltaje_linea_neutro_v/resistencia_tierra_ohm:.2f} A (solo cociente ilustrativo).\nConductor de equipos: {calibre}.\nConfiguración: {configuracion_electrodos}.',
        advertencias=advertencias,fuentes=fuentes)
