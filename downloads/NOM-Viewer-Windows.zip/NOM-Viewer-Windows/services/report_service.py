"""Memoria de cálculo con entradas, resultados, fuentes y límites de evaluación."""


def _sanitize_text(text):
    traducciones = {'Ω':'ohm','φ':'phi','√':'sqrt','≥':'>=','≤':'<=','×':'x','—':'-', '✓':'OK','✗':'NO'}
    for simbolo, equivalente in traducciones.items():
        text = str(text).replace(simbolo,equivalente)
    return text.encode('latin-1',errors='replace').decode('latin-1')


def exportar_resultados(elementos, nombre_proyecto='Proyecto NOM'):
    from fpdf import FPDF
    from fpdf.enums import XPos, YPos
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True,margin=15)
    pdf.add_page()

    def linea(texto, negrita=False, tamano=9):
        pdf.set_font('Helvetica','B' if negrita else '',tamano)
        pdf.multi_cell(0,5,_sanitize_text(texto),new_x=XPos.LMARGIN,new_y=YPos.NEXT)

    linea('Memoria de calculo - NOM-001-SEDE-2012',True,14)
    linea(nombre_proyecto,True,12)
    linea('Evaluaciones parciales. Pendientes de revision profesional.')
    for elemento,resultados in elementos.items():
        pdf.ln(3)
        linea(elemento,True,11)
        for resultado in resultados:
            linea(resultado.tipo.replace('_',' ').title(),True,10)
            linea(f'Motor {resultado.motor_version} | Funcion: {resultado.funcion}')
            linea('Entradas',True)
            for clave, valor in resultado.entradas.items():
                linea(f'{clave}: {valor}')
            linea('Resultados',True)
            for clave, valor in resultado.valores.items():
                linea(f"{clave}: {valor} {resultado.unidades.get(clave,'')}")
            estado = 'Satisface el criterio indicado' if resultado.cumple is True else ('No satisface el criterio indicado' if resultado.cumple is False else 'No evaluado')
            linea(estado,True)
            if resultado.limite_normativo:
                linea(resultado.limite_normativo)
            linea('Desarrollo',True)
            linea(resultado.detalle)
            for advertencia in resultado.advertencias:
                linea('Observacion: '+advertencia)
            for fuente in resultado.fuentes:
                linea(f"Fuente {fuente['referencia']} | pagina PDF {fuente['pagina_pdf']} | SHA-256 {fuente['sha256']}",tamano=8)
            pdf.ln(2)
    return bytes(pdf.output())
