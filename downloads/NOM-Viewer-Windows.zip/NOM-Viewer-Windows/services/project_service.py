"""Proyectos portátiles JSON. La importación recalcula; nunca confía en resultados recibidos."""
from dataclasses import asdict
import inspect
import math
import json
from core import calculos
from core.version import MOTOR_VERSION

FUNCIONES = {n:getattr(calculos,n) for n in ('calcular_caida_tension','seleccionar_calibre','calcular_cargas',
             'seleccionar_proteccion','dimensionar_transformador','calcular_puesta_tierra')}
LIMITE_BYTES = 2 * 1024 * 1024


def exportar_proyecto(nombre, elementos, sha256):
    if not nombre.strip() or len(nombre)>200 or len(elementos)>100 or sum(len(r) for r in elementos.values())>500:
        raise ValueError('El proyecto admite nombre de hasta 200 caracteres, 100 elementos y 500 cálculos.')
    datos = {'formato':'nom-viewer-proyecto','version':1,'motor_version':MOTOR_VERSION,
             'nombre':nombre,'documento_sha256':sha256,
             'elementos':{n:[{'funcion':r.funcion,'entradas':r.entradas,'resultado_registrado':asdict(r)}
                            for r in resultados] for n,resultados in elementos.items()}}
    contenido = json.dumps(datos,ensure_ascii=False,allow_nan=False,indent=2).encode('utf-8')
    if len(contenido)>LIMITE_BYTES:
        raise ValueError('El proyecto supera el tamaño de archivo admitido (2 MiB).')
    return contenido


def _sin_duplicados(pares):
    datos = {}
    for k,v in pares:
        if k in datos:
            raise ValueError('El proyecto contiene claves JSON duplicadas.')
        datos[k] = v
    return datos


def _rechazar_constante(valor):
    raise ValueError(f'Número JSON no finito: {valor}.')


def cargar_proyecto(contenido, sha256):
    if len(contenido) > LIMITE_BYTES:
        raise ValueError('El proyecto supera el límite de 2 MiB.')
    try:
        datos = json.loads(contenido,object_pairs_hook=_sin_duplicados,
                           parse_constant=_rechazar_constante)
    except (UnicodeDecodeError,json.JSONDecodeError,RecursionError) as exc:
        raise ValueError('El archivo no es un proyecto JSON válido.') from exc
    if not isinstance(datos,dict) or datos.get('formato')!='nom-viewer-proyecto' or (type(datos.get('version')) is not int or datos['version']!=1):
        raise ValueError('Formato o versión de proyecto no compatible.')
    nombre = datos.get('nombre')
    if not isinstance(nombre,str) or not nombre.strip() or len(nombre)>200:
        raise ValueError('El nombre del proyecto debe tener entre 1 y 200 caracteres.')
    if datos.get('documento_sha256') != sha256:
        raise ValueError('El proyecto corresponde a otro PDF; abre el documento correspondiente antes de cargarlo.')
    grupos = datos.get('elementos')
    if not isinstance(grupos,dict) or len(grupos)>100:
        raise ValueError('El proyecto debe contener hasta 100 elementos.')
    elementos = {}
    total = 0
    cambios = 0
    for elemento,filas in grupos.items():
        if not elemento.strip() or len(elemento)>200 or not isinstance(filas,list):
            raise ValueError('Elemento o lista de cálculos no válidos.')
        total += len(filas)
        if total>500:
            raise ValueError('El proyecto supera 500 cálculos.')
        resultados = []
        for fila in filas:
            if not isinstance(fila,dict) or fila.get('funcion') not in FUNCIONES:
                raise ValueError('El proyecto solicita una función de cálculo no admitida.')
            funcion = FUNCIONES[fila['funcion']]
            entradas = fila.get('entradas')
            if not isinstance(entradas,dict) or any(not isinstance(v,(str,int,float,type(None))) or isinstance(v,bool)
                                                  or (isinstance(v,str) and len(v)>500) or (isinstance(v,float) and not math.isfinite(v)) for v in entradas.values()):
                raise ValueError('Entradas de cálculo no válidas.')
            try:
                inspect.signature(funcion).bind(**entradas)
                resultado = funcion(**entradas)
            except (TypeError,ValueError,KeyError,OverflowError,ZeroDivisionError) as exc:
                raise ValueError(f'Cálculo inválido en {elemento}: {exc}') from exc
            if asdict(resultado) != fila.get('resultado_registrado'):
                cambios += 1
            resultados.append(resultado)
        elementos[elemento] = resultados
    return {'nombre':nombre,'elementos':elementos,'calculos':total,'resultados_distintos':cambios,
            'motor_origen':datos.get('motor_version'),'motor_actual':MOTOR_VERSION}
