"""Corpus documental de solo lectura, independiente de Streamlit y del transporte MCP."""
import hashlib
from contextlib import contextmanager
import json
import sqlite3
from pathlib import Path
import pymupdf
from services.search_service import SearchService


class NOMCorpus:
    def __init__(self, path):
        self.path = Path(path).resolve()
        self._archivo = self._estado_archivo()
        self.sha256 = hashlib.sha256(self.path.read_bytes()).hexdigest()
        metadata = json.loads(self.path.with_suffix('.references.json').read_text(encoding='utf-8'))
        if metadata['sha256'] != self.sha256:
            raise ValueError('Regenere el índice: el PDF y sus referencias no coinciden.')
        self.referencias = metadata['referencias']
        self.search = SearchService(self.path.with_suffix('.sqlite'), self.sha256)
        with pymupdf.open(self.path) as doc:
            self.paginas = len(doc)

    def _estado_archivo(self):
        st = self.path.stat()
        return st.st_size, st.st_mtime_ns, st.st_ctime_ns, st.st_ino

    def _verificar_documento(self):
        if self._estado_archivo() != self._archivo:
            raise ValueError('El PDF cambió durante la consulta. Regenere el índice y reinicie el corpus.')

    def metadata(self):
        self._verificar_documento()
        return {'documento':'NOM-001-SEDE-2012', 'sha256':self.sha256,
                'paginas':self.paginas, 'referencias':len(self.referencias),
                'paginacion':'Páginas físicas del PDF, numeradas desde 1.',
                'origen':'PDF proporcionado por el usuario; referencias detectadas automáticamente.',
                'corpus_estructurado':True, 'revision_humana':False,
                'alcance':'Texto documental; no sustituye verificación de vigencia ni revisión técnica.'}

    def cita(self, pagina):
        self._verificar_documento()
        return {'documento':'NOM-001-SEDE-2012', 'pagina_pdf':pagina,
                'sha256':self.sha256, 'uri':f'nom://{self.sha256}/paginas/{pagina}'}

    def buscar(self, consulta, limite=10):
        return [{'fragmento':item['texto'], 'cita':self.cita(item['pagina'] + 1)}
                for item in self.search.buscar(consulta, limite)]

    def leer_pagina(self, pagina, desplazamiento=0, caracteres=6000):
        self._verificar_documento()
        if not 1 <= pagina <= self.paginas:
            raise ValueError(f'Página fuera de rango: 1–{self.paginas}.')
        if desplazamiento < 0 or not 1 <= caracteres <= 12000:
            raise ValueError('Desplazamiento >= 0; caracteres entre 1 y 12000.')
        with pymupdf.open(self.path) as doc:
            texto = doc[pagina - 1].get_text()
        if desplazamiento > len(texto):
            raise ValueError('El desplazamiento supera el texto de esta página.')
        fin = min(len(texto), desplazamiento + caracteres)
        return {'texto':texto[desplazamiento:fin], 'cita':self.cita(pagina),
                'desplazamiento':desplazamiento, 'total_caracteres':len(texto),
                'siguiente_desplazamiento':fin if fin < len(texto) else None,
                'siguiente_pagina':pagina + 1 if pagina < self.paginas else None}

    def resolver(self, referencia):
        clave = referencia.strip().lower()
        if clave not in self.referencias:
            raise ValueError('Referencia no localizada. Use listar_referencias o buscar_nom.')
        pagina = self.referencias[clave] + 1
        return {'referencia':clave, 'cita':self.cita(pagina),
                'nota':'Página inicial detectada; una referencia puede continuar en páginas posteriores.',
                'pagina_inicial':self.leer_pagina(pagina)}

    def listar(self, prefijo='', desplazamiento=0, limite=50):
        if desplazamiento < 0 or not 1 <= limite <= 100:
            raise ValueError('Desplazamiento >= 0; límite entre 1 y 100.')
        claves = sorted(k for k in self.referencias if k.startswith(prefijo.strip().lower()))
        seleccion = claves[desplazamiento:desplazamiento + limite]
        fin = desplazamiento + len(seleccion)
        return {'total':len(claves), 'referencias':[{'clave':k,'cita':self.cita(self.referencias[k]+1)} for k in seleccion],
                'siguiente_desplazamiento':fin if fin < len(claves) else None}

    @contextmanager
    def _conexion(self):
        self._verificar_documento()
        db = sqlite3.connect(f'{self.path.with_suffix(".sqlite").as_uri()}?mode=ro', uri=True)
        try:
            metadata = db.execute('SELECT sha256 FROM metadata').fetchone()
            if not metadata or metadata[0] != self.sha256:
                raise ValueError('El índice estructurado no corresponde al PDF.')
            yield db
        finally:
            db.close()

    def auditoria(self):
        """Estado de extracción, límites ambiguos y revisión humana; no certificación."""
        with self._conexion() as db:
            try:
                datos = json.loads(db.execute('SELECT datos FROM auditoria').fetchone()[0])
            except sqlite3.OperationalError as exc:
                raise ValueError('Regenere el índice para preparar el corpus estructurado.') from exc
        return {'sha256':self.sha256, **datos}

    def estructura(self, referencia):
        clave = referencia.strip().lower()
        with self._conexion() as db:
            rows = db.execute('SELECT datos FROM unidades WHERE clave=?', (clave,)).fetchall()
        if not rows:
            raise ValueError('No hay una unidad estructurada para esta referencia; use buscar_nom o leer_pagina.')
        if len(rows) > 1:
            raise ValueError('Encabezado ambiguo: requiere revisión antes de leerlo como una disposición.')
        unidad = json.loads(rows[0][0])
        with self._conexion() as db:
            hijos = [r[0] for r in db.execute('SELECT clave FROM unidades WHERE padre=? ORDER BY id', (clave,))]
        return {**unidad, 'hijos':hijos, 'cita_inicio':self.cita(unidad['pagina'] + 1),
                'cita_fin':self.cita(unidad['pagina_fin'] + 1)}

    def leer_disposicion(self, referencia, desplazamiento=0, caracteres=6000):
        """Lee exclusivamente el segmento delimitado, conservando páginas y offsets originales."""
        if desplazamiento < 0 or not 1 <= caracteres <= 12000:
            raise ValueError('Desplazamiento >= 0; caracteres entre 1 y 12000.')
        unidad = self.estructura(referencia)
        longitud = unidad['fin'] - unidad['inicio']
        if desplazamiento > longitud:
            raise ValueError('Desplazamiento fuera de la disposición.')
        inicio = unidad['inicio'] + desplazamiento
        fin = min(unidad['fin'], inicio + caracteres)
        fragmentos = []
        with self._conexion() as db:
            posicion = 0
            for pagina, largo in db.execute('SELECT rowid, length(texto) FROM paginas ORDER BY rowid'):
                if posicion >= fin:
                    break
                if posicion + largo > inicio:
                    texto = db.execute('SELECT texto FROM paginas WHERE rowid=?', (pagina,)).fetchone()[0]
                    a, b = max(0, inicio - posicion), min(largo, fin - posicion)
                    fragmentos.append({'texto':texto[a:b], 'offset_inicio':a, 'offset_fin':b, 'cita':self.cita(pagina)})
                posicion += largo
        consumido = fin - unidad['inicio']
        return {'referencia':unidad['clave'], 'titulo':unidad['titulo'], 'padre':unidad['padre'],
                'estado':unidad['estado'], 'motivos_revision':unidad['motivos'], 'revision_humana':False,
                'hijos':unidad['hijos'], 'subdivisiones':unidad.get('subdivisiones', []), 'fragmentos':fragmentos, 'total_caracteres':longitud,
                'desplazamiento':desplazamiento,
                'siguiente_desplazamiento':consumido if consumido < longitud else None,
                'segmento_completo':desplazamiento == 0 and consumido == longitud,
                'aviso':'Límites detectados automáticamente. Incluye el texto extraído entre encabezados; no asegura fidelidad de tablas ni revisión normativa.'}
