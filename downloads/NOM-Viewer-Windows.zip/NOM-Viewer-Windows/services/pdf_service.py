"""Documentos privados por sesión, renderizado bajo demanda y caché LRU acotada."""
from collections import OrderedDict
from dataclasses import dataclass
import math
import hashlib
import pymupdf as fitz


class ArchivoInvalidoError(ValueError):
    pass


class PDFNoCaregadoError(RuntimeError):
    pass


class ArticuloNoEncontradoError(KeyError):
    pass


@dataclass(frozen=True)
class PaginaRenderizada:
    imagen: bytes


class PDFService:
    def __init__(self, mapa_articulos=None, cache_paginas=25, cache_bytes=32 * 1024 * 1024):
        self.document_id = None
        self._doc = None
        self._mapa = dict(mapa_articulos or {})
        self._cache_size = max(1, cache_paginas)
        self._cache_limit = max(1, cache_bytes)
        self._cache = OrderedDict()
        self._cache_bytes = 0
        self._por_pagina = {}
        for clave, pagina in self._mapa.items():
            self._por_pagina.setdefault(pagina, []).append(clave)

    @property
    def esta_cargado(self):
        return self._doc is not None

    @property
    def total_paginas(self):
        return len(self._doc) if self._doc is not None else 0

    def cargar_desde_bytes(self, contenido):
        nuevo = None
        try:
            nuevo = fitz.open(stream=contenido, filetype="pdf")
            if nuevo.needs_pass or not len(nuevo):
                raise ValueError("El PDF debe contener páginas y no requerir contraseña.")
        except Exception as exc:
            if nuevo is not None:
                nuevo.close()
            raise ArchivoInvalidoError(f"No se pudo cargar el PDF: {exc}") from exc
        self.close()
        self._doc = nuevo
        self.document_id = hashlib.sha256(contenido).hexdigest()
        return self

    def close(self):
        if self._doc is not None:
            self._doc.close()
        self._doc = None
        self.document_id = None
        self._cache.clear()
        self._cache_bytes = 0

    @property
    def mapa_articulos(self):
        return dict(self._mapa)

    def tiene_articulo(self, clave):
        return clave.lower() in self._mapa

    def pagina_de_articulo(self, clave):
        clave = clave.lower()
        if clave not in self._mapa:
            raise ArticuloNoEncontradoError(clave)
        pagina = self._mapa[clave]
        if not 0 <= pagina < self.total_paginas:
            raise ArticuloNoEncontradoError(f"{clave}: página fuera de este documento")
        return pagina

    def pagina_anterior(self, pagina):
        return max(0, pagina - 1)

    def pagina_siguiente(self, pagina):
        return max(0, min(self.total_paginas - 1, pagina + 1))

    def articulos_en_pagina(self, pagina):
        return list(self._por_pagina.get(pagina, ()))

    def renderizar_pagina(self, pagina, zoom=1.5):
        if self._doc is None or not 0 <= pagina < self.total_paginas:
            raise PDFNoCaregadoError("Página no disponible.")
        if not math.isfinite(zoom) or not 0.5 <= zoom <= 3:
            raise ValueError("Zoom fuera de rango (0.5–3).")
        key = (pagina, float(zoom))
        if key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key]
        page = self._doc.load_page(pagina)
        # Limita la imagen a 8 megapíxeles incluso con páginas de gran formato.
        scale = min(zoom, math.sqrt(8_000_000 / max(1, page.rect.width * page.rect.height)))
        pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), colorspace=fitz.csRGB, alpha=False)
        result = PaginaRenderizada(pix.tobytes("png"))
        size = len(result.imagen)
        if size <= self._cache_limit:
            while self._cache and (len(self._cache) >= self._cache_size or self._cache_bytes + size > self._cache_limit):
                _, old = self._cache.popitem(last=False)
                self._cache_bytes -= len(old.imagen)
            self._cache[key] = result
            self._cache_bytes += size
        return result
