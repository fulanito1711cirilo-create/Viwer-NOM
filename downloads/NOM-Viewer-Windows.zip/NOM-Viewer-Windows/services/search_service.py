"""Búsqueda local FTS5; conexiones breves y consultas literales parametrizadas."""
import sqlite3
from contextlib import closing
import re
from pathlib import Path


class SearchService:
    def __init__(self, path, document_id):
        self.path = Path(path)
        self.document_id = document_id

    def buscar(self, texto, limite=20):
        palabras = re.findall(r'\w+', texto[:500], flags=re.UNICODE)
        if not palabras:
            return []
        # Trata el texto como palabras, nunca como operadores o SQL del usuario.
        consulta = ' AND '.join('"' + p.replace('"', '""') + '"' for p in palabras)
        with closing(sqlite3.connect(f'{self.path.resolve().as_uri()}?mode=ro', uri=True)) as db:
            metadata = db.execute('SELECT sha256 FROM metadata').fetchone()
            if not metadata or metadata[0] != self.document_id:
                raise ValueError('El índice no corresponde al documento abierto.')
            rows = db.execute("SELECT rowid - 1, snippet(paginas, 0, '', '', ' … ', 32) FROM paginas WHERE paginas MATCH ? ORDER BY rank LIMIT ?", (consulta, max(1, min(limite, 50)))).fetchall()
        return [{'pagina': p, 'texto': t} for p, t in rows]
