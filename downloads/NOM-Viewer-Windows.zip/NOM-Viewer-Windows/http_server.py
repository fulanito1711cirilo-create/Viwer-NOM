"""MCP público de consulta por Streamable HTTP, sin acceso a proyectos de usuarios."""
from collections import deque
from contextlib import asynccontextmanager
import asyncio
import os
import re
import time
from urllib.parse import urlsplit

from mcp.server.transport_security import TransportSecuritySettings
from starlette.responses import JSONResponse
from starlette.routing import Route
import uvicorn
from core.version import MOTOR_VERSION
from mcp_server import crear_servidor, corpus


def _origen(valor):
    url = urlsplit(valor)
    if url.scheme not in ('https','http') or not url.hostname or url.username or url.password or url.query or url.fragment or url.path not in ('','/'):
        raise ValueError('Las URL deben indicar un origen, sin ruta, credenciales ni parámetros.')
    if url.scheme == 'http' and url.hostname not in ('127.0.0.1','localhost'):
        raise ValueError('El acceso público requiere un origen HTTPS.')
    return f'{url.scheme}://{url.netloc}'


def configuracion_seguridad():
    hosts = ['127.0.0.1','127.0.0.1:*','localhost','localhost:*']
    origins = ['https://chatgpt.com','https://chat.openai.com']
    publico = os.environ.get('MCP_PUBLIC_URL')
    render = os.environ.get('RENDER_EXTERNAL_HOSTNAME')
    if publico:
        origen = _origen(publico)
        hosts.append(urlsplit(origen).netloc)
        origins.append(origen)
    if render:
        if not re.fullmatch(r'[a-zA-Z0-9.-]+',render):
            raise ValueError('Hostname público de Render no válido.')
        hosts.append(render)
        origins.append('https://' + render)
    for origen in os.environ.get('MCP_ALLOWED_ORIGINS','').split(','):
        if origen.strip():
            origins.append(_origen(origen.strip()))
    return TransportSecuritySettings(enable_dns_rebinding_protection=True,
                                     allowed_hosts=hosts,allowed_origins=origins)


class LimitesPublicos:
    """Límites por proceso; la puerta de enlace puede aplicar cuotas adicionales."""
    def __init__(self,app,por_minuto=300,simultaneas=8):
        self.app=app
        self.por_minuto=por_minuto
        self.simultaneas=simultaneas
        self.peticiones=deque()
        self.activas=0
        self.lock=asyncio.Lock()

    async def __call__(self,scope,receive,send):
        if scope['type']!='http' or scope['path']!='/mcp':
            return await self.app(scope,receive,send)
        async with self.lock:
            ahora=time.monotonic()
            while self.peticiones and ahora-self.peticiones[0]>=60:
                self.peticiones.popleft()
            if len(self.peticiones)>=self.por_minuto:
                rechazo=JSONResponse({'error':'Límite temporal de solicitudes. Reintenta más tarde.'},429,headers={'Retry-After':'60'})
            elif self.activas>=self.simultaneas:
                rechazo=JSONResponse({'error':'Servidor ocupado. Reintenta.'},503,headers={'Retry-After':'1'})
            else:
                rechazo=None
                self.peticiones.append(ahora)
                self.activas+=1
        if rechazo:
            return await rechazo(scope,receive,send)
        try:
            await self.app(scope,receive,send)
        finally:
            async with self.lock:
                self.activas-=1


def crear_app():
    servidor=crear_servidor(stateless_http=True,json_response=True,max_request_body_size=65536,
                            transport_security=configuracion_seguridad())
    app=servidor.streamable_http_app()
    original=app.router.lifespan_context

    @asynccontextmanager
    async def lifespan(app):
        # Fallar durante el arranque si el PDF o el esquema de índices están incompletos.
        corpus().auditoria()
        async with original(app):
            yield

    async def salud(request):
        return JSONResponse({'status':'ok','service':'nom-mcp','motor_version':MOTOR_VERSION})

    app.router.lifespan_context=lifespan
    app.router.routes.insert(0,Route('/healthz',salud,methods=['GET']))
    app.add_middleware(LimitesPublicos,
                       por_minuto=int(os.environ.get('MCP_REQUESTS_PER_MINUTE','300')),
                       simultaneas=int(os.environ.get('MCP_MAX_CONCURRENT','8')))
    return app


if __name__=='__main__':
    uvicorn.run(crear_app(),host=os.environ.get('MCP_BIND_HOST','0.0.0.0'),port=int(os.environ.get('PORT','8000')),
                access_log=False,proxy_headers=True)
