"""Entrada Streamlit. Ejecutar: streamlit run app.py."""
import streamlit as st
from ui.state import inicializar
from ui.theme import aplicar_tema
from ui.sidebar import mostrar_sidebar
from ui.views.manual import _vista_manual
from ui.views.visor import _vista_visor
from ui.views.calculadoras import _vista_calculadoras
from ui.views.validacion import _vista_validacion
from ui.views.resultados import _vista_resultados_acumulados

st.set_page_config(page_title="NOM Viewer — NOM-001-SEDE-2012", page_icon="⚡", layout="wide")
inicializar()
aplicar_tema()
mostrar_sidebar()
VISTAS = {"manual": _vista_manual, "visor": _vista_visor, "calculadoras": _vista_calculadoras,
          "validacion": _vista_validacion, "resultados": _vista_resultados_acumulados}
VISTAS.get(st.session_state.vista, _vista_manual)()
