import streamlit as st
from services.pdf_service import ArchivoInvalidoError
from ui.state import obtener_pdf_service, crear_servicio
from ui.components import _navegar_articulo
CAIDA_TENSION_MAX_PCT = 3.0
RESISTENCIA_TIERRA_MAX_OHM = 5.0

def mostrar_sidebar():
    with st.sidebar:
        st.markdown("## ⚡ NOM Viewer")
        st.caption("NOM-001-SEDE-2012 — Asistente Técnico")
        st.divider()
    
        st.markdown('<div class="sec-header">Archivo NOM</div>', unsafe_allow_html=True)
        pdf_upload = st.file_uploader(
            "Sube la NOM-001-SEDE-2012.pdf", type=["pdf"],
            help="Descárgalo gratis desde el DOF o gob.mx",
            label_visibility="collapsed",
        )
    
        if pdf_upload:
            contenido = pdf_upload.getvalue()
            if contenido != st.session_state.pdf_bytes:
                try:
                    meta = crear_servicio(contenido)
                    obtener_pdf_service().close()
                    st.session_state.pdf_service = meta
                    st.session_state.pop("unidad_lectura", None)
                    st.session_state.marcadores = []
                    st.session_state.busqueda_resultados = []
                    st.session_state.pdf_bytes = contenido
                    st.session_state.pagina_pdf = 0
                    st.success(f"✓ {meta.total_paginas} páginas cargadas")
                except ArchivoInvalidoError as e:
                    st.error(str(e))
        elif obtener_pdf_service().esta_cargado:
            st.caption(f"✓ {obtener_pdf_service().total_paginas} páginas en memoria")
        else:
            st.info("Sube el PDF para activar el Visor NOM")
    
        st.divider()
    
        # ==========================================================================
        # ENLACES ÚTILES (añadidos)
        # ==========================================================================
        st.markdown('<div class="sec-header">🌐 Enlaces útiles</div>', unsafe_allow_html=True)
        
        # Botón para retroalimentación (Google Forms)
        st.link_button(
            "📝 Formulario de retroalimentación",
            "https://docs.google.com/forms/d/e/1FAIpQLSckNJrFWfLzLyAl2qAxSwr7HLRo8QVfvjOT8-Rjia5qwN_aSg/viewform?usp=header",
            help="Abre el formulario para enviar comentarios, reportar errores o sugerir mejoras.",
            use_container_width=True,
        )
        
        # Botón para descargar la NOM en PDF (Google Drive)
        st.link_button(
            "📥 Descargar NOM-001-SEDE-2012 (PDF)",
            "https://drive.google.com/file/d/1pD823-cEUWY1tPMqJYO96YQxuE9v3FgX/view?usp=sharing",
            help="Descarga el PDF oficial de la NOM-001-SEDE-2012 (desde Google Drive). Luego súbelo en la sección 'Archivo NOM' para usar el visor.",
            use_container_width=True,
        )
        
        st.caption("Puedes consultar el documento incluido o cargar otra copia en el panel superior.")
        st.divider()
        # ==========================================================================
    
        opciones = {
            "📘 Manual": "manual",
            "📄 Visor NOM": "visor",
            "🧮 Calculadoras": "calculadoras",
            "✅ Validación": "validacion",
            "📋 Resultados Acumulados": "resultados",
        }
        vista_actual = st.session_state.vista
        idx_actual = list(opciones.values()).index(vista_actual) if vista_actual in opciones.values() else 0
    
        seleccion = st.radio(
            "Sección", list(opciones.keys()),
            index=idx_actual, label_visibility="collapsed",
        )
        nueva_vista = opciones[seleccion]
        if nueva_vista != st.session_state.vista:
            st.session_state.vista = nueva_vista
            st.rerun()
    
        st.divider()
    
        st.markdown('<div class="sec-header">Ir a artículo</div>', unsafe_allow_html=True)
        art_buscar = st.text_input(
            "Ej: art220-12, tab9",
            label_visibility="collapsed",
            placeholder="art...",
            key="sidebar_art_input",
        )
        if st.button("Buscar", key="sidebar_buscar", use_container_width=True):
            if art_buscar:
                _navegar_articulo(art_buscar.strip().lower())
