import streamlit as st

def aplicar_tema():
    st.markdown("""
    <style>
    html, body, [class*="css"] {
        font-family: 'IBM Plex Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    :root {
        --c-bg: #0f1117; --c-surface: #1a1d27; --c-border: #2a2d3e;
        --c-accent: #f5c518; --c-accent2: #3d8ef5; --c-error: #e85555;
        --c-warn: #f5a623; --c-ok: #52c77a; --c-text: #e2e4ed; --c-muted: #8b8fa8;
    }
    .card { background: var(--c-surface); border: 1px solid var(--c-border); border-radius: 6px; padding: 16px 20px; margin-bottom: 12px; }
    .card-accent { border-left: 3px solid var(--c-accent); }
    .card-error  { border-left: 3px solid var(--c-error);  background: #1f1518; }
    .card-warn   { border-left: 3px solid var(--c-warn);   background: #1f1a12; }
    .card-ok     { border-left: 3px solid var(--c-ok);     background: #121f16; }
    .formula { background: #0a0c14; border: 1px solid var(--c-border); border-radius: 4px; padding: 10px 14px; font-family: 'IBM Plex Mono', monospace; font-size: 0.88rem; color: var(--c-accent); margin: 8px 0; }
    .art-tag { display: inline-block; background: #1a2235; border: 1px solid var(--c-accent2); border-radius: 3px; padding: 2px 7px; font-size: 0.78rem; color: var(--c-accent2); font-family: monospace; margin: 2px 3px; }
    .big-val { font-size: 2.2rem; font-weight: 600; font-family: monospace; color: var(--c-accent); line-height: 1.1; }
    .big-label { font-size: 0.78rem; color: var(--c-muted); text-transform: uppercase; letter-spacing: 0.08em; }
    .sec-header { font-size: 0.72rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.12em; color: var(--c-muted); border-bottom: 1px solid var(--c-border); padding-bottom: 6px; margin: 20px 0 12px 0; }
    .badge-ok   { color: var(--c-ok);    font-weight: 600; }
    .badge-err  { color: var(--c-error); font-weight: 600; }
    .badge-warn { color: var(--c-warn);  font-weight: 600; }
    #MainMenu, footer { visibility: hidden; }
    .block-container { padding-top: 1.2rem; padding-bottom: 2rem; }
    </style>
    """, unsafe_allow_html=True)
