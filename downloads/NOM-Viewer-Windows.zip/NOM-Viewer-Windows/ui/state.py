"""Estado privado por sesión; nunca compartir documentos mutables entre usuarios."""
from copy import deepcopy
import os
import json
from pathlib import Path
import streamlit as st
from config.normas.nom_001_sede_2012 import MAPA
from services.pdf_service import PDFService

DEFAULTS = {"proyecto_nombre":"Proyecto NOM", "vista": "manual", "pagina_pdf": 0, "zoom_pdf": 1.5,
            "marcadores": [], "busqueda_resultados": [], "pdf_bytes": None, "resultados": {}, "datos_evaluacion": {}, "elementos": {}}

def inicializar():
    for key, value in DEFAULTS.items():
        if key not in st.session_state:
            st.session_state[key] = deepcopy(value)

def obtener_pdf_service():
    if "pdf_service" not in st.session_state:
        svc = PDFService(mapa_articulos=MAPA)
        path = ruta_pdf()
        if path.is_file():
            contenido = path.read_bytes()
            svc = crear_servicio(contenido)
        st.session_state.pdf_service = svc
    return st.session_state.pdf_service


def ruta_pdf():
    return Path(os.environ.get("NOM_PDF_PATH", str(Path(__file__).resolve().parents[1] / "data/NOM.pdf")))


def crear_servicio(contenido):
    import hashlib
    digest = hashlib.sha256(contenido).hexdigest()
    metadata = ruta_pdf().with_suffix('.references.json')
    mapa = MAPA
    if metadata.is_file():
        indice = json.loads(metadata.read_text(encoding='utf-8'))
        if indice['sha256'] == digest:
            mapa = indice['referencias']
    return PDFService(mapa_articulos=mapa).cargar_desde_bytes(contenido)
