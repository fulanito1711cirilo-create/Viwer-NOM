from html import escape
import streamlit as st
from core.calculos import ResultadoCalculo
from services.pdf_service import ArticuloNoEncontradoError
from ui.state import obtener_pdf_service
CAIDA_TENSION_MAX_PCT = 3.0
RESISTENCIA_TIERRA_MAX_OHM = 5.0

def _navegar_articulo(clave: str) -> None:
    svc = obtener_pdf_service()
    if svc.esta_cargado:
        try:
            st.session_state.pagina_pdf = svc.pagina_de_articulo(clave)
        except ArticuloNoEncontradoError:
            st.toast(f"La referencia {clave} no está disponible en este PDF.", icon="⚠️")
            return
    st.session_state.vista = "visor"
    st.rerun()


def _comp_resultado(resultado: ResultadoCalculo) -> None:
    cumple = resultado.cumple
    cls = "card-ok" if cumple is True else ("card-error" if cumple is False else "card")

    items = list(resultado.valores.items())
    val_principal = items[0][1] if items else "—"
    unidad_principal = resultado.unidades.get(items[0][0], "") if items else ""

    if isinstance(val_principal, float):
        val_str = f"{val_principal:.3g}"
    elif isinstance(val_principal, str):
        val_str = val_principal
    else:
        val_str = str(val_principal)

    if cumple is True:
        estado_html = '<span class="badge-ok">✓ SATISFACE EL CRITERIO</span>'
    elif cumple is False:
        estado_html = '<span class="badge-err">✗ NO SATISFACE EL CRITERIO</span>'
    else:
        estado_html = ""

    st.markdown(f"""
    <div class="card {cls}">
        <div class="big-val">{escape(val_str)}
            <span style="font-size:1rem;color:var(--c-muted)">{escape(unidad_principal)}</span>
        </div>
        <div class="big-label">
            {resultado.tipo.replace("_"," ").title()} {estado_html}
        </div>
    </div>
    """, unsafe_allow_html=True)

    if not resultado.revision_profesional:
        st.caption('Evaluación parcial del criterio indicado; pendiente de revisión profesional.')
    for fuente in resultado.fuentes:
        st.caption(f"Fuente: {fuente['referencia']} · página PDF {fuente['pagina_pdf']} · SHA-256 {fuente['sha256'][:12]}…")

    limite = getattr(resultado, 'limite_normativo', '')
    if limite:
        st.caption(f"📏 {limite}")

    articulos = getattr(resultado, 'articulos_citados', [])
    if articulos:
        arts_html = " ".join(f'<span class="art-tag">{a}</span>' for a in articulos)
        st.markdown(arts_html, unsafe_allow_html=True)

    for adv in resultado.advertencias:
        st.warning(adv)

    if resultado.entradas:
        with st.expander('Entradas y versión del cálculo'):
            st.json(resultado.entradas)
            st.caption(f'Motor {resultado.motor_version} · {resultado.funcion}')

    with st.expander("Detalle del cálculo"):
        st.code(resultado.detalle, language=None)


def _comp_boton_articulo(label: str, clave: str, key_suffix: str = "") -> None:
    key = f"art_{clave}_{key_suffix}"
    if st.button(f"📄 {label}", key=key, help=f"Ver {clave} en la NOM"):
        _navegar_articulo(clave)


def _comp_guardar_en_elemento(nombre_el: str, resultado: ResultadoCalculo) -> None:
    if nombre_el.strip():
        elementos = st.session_state.elementos
        if nombre_el not in elementos:
            elementos[nombre_el] = []
        elementos[nombre_el].append(resultado)
        st.session_state.resultados[resultado.tipo] = resultado
        st.session_state.datos_evaluacion.update(resultado.valores)
        st.toast(f"✓ Cálculo '{resultado.tipo.replace('_',' ').title()}' añadido a '{nombre_el}'", icon="✅")
    else:
        st.error("Debes especificar un nombre para el elemento eléctrico.")


def _comp_separador(titulo: str) -> None:
    st.markdown(f'<div class="sec-header">{titulo}</div>', unsafe_allow_html=True)


