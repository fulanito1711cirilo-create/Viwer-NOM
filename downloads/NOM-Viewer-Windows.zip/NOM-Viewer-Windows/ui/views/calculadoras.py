import streamlit as st
from core.calculos import calcular_caida_tension, calcular_cargas, calcular_puesta_tierra, dimensionar_transformador, seleccionar_calibre, seleccionar_proteccion, CALIBRES_ORDENADOS, FACTORES_DEMANDA
CAIDA_TENSION_MAX_PCT = 3.0
RESISTENCIA_TIERRA_MAX_OHM = 5.0
from ui.components import _comp_resultado, _comp_boton_articulo, _comp_guardar_en_elemento, _comp_separador

def _vista_calculadoras() -> None:
    st.title("🧮 Calculadoras Eléctricas")
    st.caption("Resultados con respaldo normativo. Asigna cada cálculo a un elemento del sistema eléctrico.")

    opciones = ["Caída de Tensión", "Calibre", "Cargas", "Protecciones", "Transformador", "Puesta a Tierra"]
    seleccion = st.selectbox("Calculadora", opciones, key="calculadora_activa")
    calculadora = opciones.index(seleccion)

    # --- Caída de Tensión ---
    if calculadora == 0:
        _comp_separador("Caída de Tensión — Tabla 9 NOM-001-SEDE-2012")
        nombre_elem = st.text_input("Nombre del elemento eléctrico", key="elem_cdt", placeholder="Ej. Alimentador principal")
        c1, c2, c3 = st.columns(3)
        with c1:
            cdt_tipo = st.selectbox("Tipo", ["Trifásico","Monofásico 2 hilos","Monofásico 3 hilos"], key="cdt_tipo")
            cdt_mat  = st.selectbox("Material", ["cobre","aluminio"], key="cdt_mat")
        with c2:
            cdt_cond = st.selectbox("Conduit", ["PVC","Aluminio","Acero"], key="cdt_cond")
            cdt_cal  = st.selectbox("Calibre AWG/kcmil", CALIBRES_ORDENADOS, index=5, key="cdt_cal")
        with c3:
            cdt_L  = st.number_input("Longitud (m)",         min_value=0.1, value=50.0,  key="cdt_L")
            cdt_I  = st.number_input("Corriente (A)",        min_value=0.1, value=20.0,  key="cdt_I")
        c4, c5, c6 = st.columns(3)
        with c4: cdt_V  = st.number_input("Voltaje (V)",     min_value=1.0, value=220.0, key="cdt_V")
        with c5: cdt_fp = st.number_input("Factor potencia", min_value=0.01, max_value=1.0, value=0.85, key="cdt_fp")
        with c6: cdt_Cf = st.number_input("Cond. / fase",    min_value=1, value=1, key="cdt_Cf")

        if st.button("Calcular caída", key="btn_cdt", type="primary"):
            try:
                res = calcular_caida_tension(cdt_tipo, cdt_mat, cdt_cond, cdt_cal, cdt_L, cdt_I, cdt_V, cdt_fp, cdt_Cf)
                _comp_guardar_en_elemento(nombre_elem, res)
                _comp_resultado(res)
                c1b, c2b = st.columns(2)
                with c1b: _comp_boton_articulo("Art. 210-19", "art210-19", "cdt_r1")
                with c2b: _comp_boton_articulo("Tabla 9",     "tab9",      "cdt_r2")
            except (ValueError, KeyError) as e:
                st.error(str(e))

    # --- Calibre ---
    if calculadora == 1:
        _comp_separador("Selección de Calibre — Ampacidad y Caída de Tensión")
        nombre_elem = st.text_input("Nombre del elemento eléctrico", key="elem_cc", placeholder="Ej. Alimentador principal")
        c1, c2, c3 = st.columns(3)
        with c1:
            cc_tipo  = st.selectbox("Tipo", ["Trifásico","Monofásico 2 hilos","Monofásico 3 hilos"], key="cc_tipo")
            cc_mat   = st.selectbox("Material", ["cobre","aluminio"], key="cc_mat")
        with c2:
            cc_cond  = st.selectbox("Conduit", ["PVC","Aluminio","Acero"], key="cc_cond")
            cc_temp  = st.number_input("Temp. ambiente (°C)", value=30, step=5, key="cc_temp")
        with c3:
            cc_I     = st.number_input("Corriente (A)",   min_value=0.1, value=30.0, key="cc_I")
            cc_L     = st.number_input("Longitud (m)",    min_value=0.1, value=40.0, key="cc_L")
        c4, c5, c6 = st.columns(3)
        with c4: cc_V    = st.number_input("Voltaje (V)",    min_value=1.0, value=220.0, key="cc_V")
        with c5: cc_fp   = st.number_input("Factor potencia",min_value=0.01, max_value=1.0, value=0.85, key="cc_fp")
        with c6: cc_nc   = st.number_input("Cond. en canaliz.", min_value=1, value=3, key="cc_nc")
        cc_caida = st.slider("Caída máxima (%)", 0.5, 5.0, 3.0, 0.5, key="cc_caida")

        if st.button("Seleccionar calibre", key="btn_cc", type="primary"):
            try:
                res = seleccionar_calibre(
                    corriente_carga_a=cc_I, longitud_m=cc_L, voltaje_v=cc_V,
                    tipo_circuito=cc_tipo, material=cc_mat, conduit=cc_cond,
                    temp_ambiente_c=cc_temp, num_conductores_canaliz=cc_nc,
                    factor_potencia=cc_fp, caida_max_pct=cc_caida,
                )
                _comp_guardar_en_elemento(nombre_elem, res)
                _comp_resultado(res)
                c1b, c2b, c3b = st.columns(3)
                with c1b: _comp_boton_articulo("Tabla 310-15(b)(16)", "tab310-15b16", "cc_r1")
                with c2b: _comp_boton_articulo("Art. 310",            "art310",       "cc_r2")
                with c3b: _comp_boton_articulo("Art. 210-19",         "art210-19",    "cc_r3")
            except (ValueError, KeyError) as e:
                st.error(str(e))

    # --- Cargas ---
    if calculadora == 2:
        _comp_separador("Cálculo de Cargas — Art. 220")
        nombre_elem = st.text_input("Nombre del elemento eléctrico", key="elem_cg", placeholder="Ej. Tablero principal")
        c1, c2 = st.columns(2)
        with c1:
            cg_tipo = st.selectbox("Tipo de inmueble", list(FACTORES_DEMANDA.keys()), key="cg_tipo")
            cg_area = st.number_input("Superficie (m²)", min_value=1.0, value=100.0, step=10.0, key="cg_area")
        with c2:
            cg_V    = st.number_input("Voltaje (V)",     min_value=1.0, value=220.0, key="cg_V")
            cg_fp   = st.number_input("Factor potencia", min_value=0.01, max_value=1.0, value=0.90, key="cg_fp")
        _comp_separador("Cargas específicas")
        c3, c4, c5 = st.columns(3)
        with c3:
            cg_cal  = st.number_input("Calefacción / HVAC (W)", value=0.0, step=500.0, key="cg_cal")
            cg_agua = st.number_input("Calentador agua (W)",    value=0.0, step=500.0, key="cg_agua")
        with c4:
            cg_est  = st.number_input("Estufa / Horno (W)",     value=0.0, step=500.0, key="cg_est")
            cg_mot  = st.number_input("Motores total (W)",      value=0.0, step=500.0, key="cg_mot")
        with c5:
            cg_aire = st.number_input("Aire acondicionado (W)", value=0.0, step=500.0, key="cg_aire")
            cg_otro = st.number_input("Otros equipos (W)",      value=0.0, step=500.0, key="cg_otro")

        if st.button("Calcular cargas", key="btn_cg", type="primary"):
            try:
                res = calcular_cargas(
                    tipo_inmueble=cg_tipo, area_m2=cg_area,
                    carga_calefaccion_w=cg_cal, carga_agua_w=cg_agua,
                    carga_estufa_w=cg_est, carga_motores_w=cg_mot,
                    carga_aire_w=cg_aire, carga_otros_w=cg_otro,
                    voltaje_v=cg_V, factor_potencia=cg_fp,
                )
                _comp_guardar_en_elemento(nombre_elem, res)
                _comp_resultado(res)
                c1b, c2b, c3b = st.columns(3)
                with c1b: _comp_boton_articulo("Art. 220-12","art220-12","cg_r1")
                with c2b: _comp_boton_articulo("Art. 220-14","art220-14","cg_r2")
                with c3b: _comp_boton_articulo("Art. 220-52","art220-52","cg_r3")
            except (ValueError, KeyError) as e:
                st.error(str(e))

    # --- Protecciones ---
    if calculadora == 3:
        _comp_separador("Selección de Protecciones — Art. 240")
        nombre_elem = st.text_input("Nombre del elemento eléctrico", key="elem_pt", placeholder="Ej. Interruptor principal")
        c1, c2 = st.columns(2)
        with c1:
            pt_tipo = st.selectbox("Tipo de carga", ["General","Motor","Transformador"], key="pt_tipo")
            pt_Ic   = st.number_input("Corriente de carga (A)", min_value=0.1, value=30.0, key="pt_Ic")
        with c2:
            pt_icc  = st.number_input("Icc disponible (kA)",   min_value=0.1, value=10.0, key="pt_icc")
            pt_amp  = st.number_input("Ampacidad conductor (A)",min_value=0.0, value=0.0,  key="pt_amp",
                                      help="0 = no verificar coordinación")

        if st.button("Seleccionar protección", key="btn_pt", type="primary"):
            try:
                amp_cond = pt_amp if pt_amp > 0 else None
                res = seleccionar_proteccion(
                    tipo_carga=pt_tipo, corriente_carga_a=pt_Ic,
                    icc_disponible_ka=pt_icc, ampacidad_conductor_a=amp_cond,
                )
                _comp_guardar_en_elemento(nombre_elem, res)
                _comp_resultado(res)
                c1b, c2b = st.columns(2)
                with c1b: _comp_boton_articulo("Art. 240",  "art240",   "pt_r1")
                with c2b: _comp_boton_articulo("Art. 240-6","art240-6", "pt_r2")
            except (ValueError, KeyError) as e:
                st.error(str(e))

    # --- Transformador ---
    if calculadora == 4:
        _comp_separador("Dimensionamiento de Transformador — Art. 450")
        nombre_elem = st.text_input("Nombre del elemento eléctrico", key="elem_tr", placeholder="Ej. Transformador T1")
        c1, c2, c3 = st.columns(3)
        with c1:
            tr_carga = st.number_input("Carga demandada (kVA)", min_value=1.0, value=150.0, step=10.0, key="tr_carga")
            tr_fc    = st.number_input("Factor crecimiento (%)",value=20.0, step=5.0, key="tr_fc")
        with c2:
            tr_vprim = st.selectbox("Voltaje primario (V)",  [13200,23000,34500,44000,69000], key="tr_vprim")
            tr_vsec  = st.selectbox("Voltaje secundario (V)",[120,208,220,480], key="tr_vsec")
        with c3:
            tr_sis = st.selectbox("Sistema", ["Trifásico","Monofásico"], key="tr_sis")

        if st.button("Dimensionar transformador", key="btn_tr", type="primary"):
            try:
                res = dimensionar_transformador(
                    carga_demandada_kva=tr_carga,
                    voltaje_primario_v=float(tr_vprim),
                    voltaje_secundario_v=float(tr_vsec),
                    sistema=tr_sis,
                    factor_crecimiento=tr_fc / 100.0,
                )
                _comp_guardar_en_elemento(nombre_elem, res)
                _comp_resultado(res)
                c1b, c2b = st.columns(2)
                with c1b: _comp_boton_articulo("Art. 450",  "art450",   "tr_r1")
                with c2b: _comp_boton_articulo("Art. 450-3","art450-3", "tr_r2")
            except (ValueError, KeyError) as e:
                st.error(str(e))

    # --- Puesta a Tierra ---
    if calculadora == 5:
        _comp_separador("Puesta a Tierra — Art. 250")
        nombre_elem = st.text_input("Nombre del elemento eléctrico", key="elem_ptt", placeholder="Ej. Sistema de tierra general")
        c1, c2 = st.columns(2)
        with c1:
            ptt_V    = st.number_input("Voltaje línea-neutro (V)", min_value=1.0, value=127.0, step=10.0, key="ptt_V")
            ptt_R    = st.number_input("Resistencia de tierra (Ω)",min_value=0.1, value=5.0,   step=0.5,  key="ptt_R")
        with c2:
            ptt_mat  = st.selectbox("Material conductor tierra", ["Cobre","Aluminio"], key="ptt_mat")
            ptt_Ialim= st.number_input("Capacidad/ajuste de protección (A)", min_value=0.0, value=0.0, key="ptt_Ialim",
                                       help="0 = no dimensionar. Usar la capacidad/ajuste del dispositivo, no la corriente de carga.")

        ptt_contexto = st.selectbox('Electrodos', ['no_especificada','unico_varilla_tuberia_placa'],
            format_func=lambda s:'Configuración no especificada' if s=='no_especificada' else 'Un solo electrodo de varilla, tubería o placa',key='ptt_contexto')
        st.caption('El conductor de equipos y el conductor al electrodo tienen criterios distintos. Esta consulta no certifica la instalación.')
        if st.button("Calcular tierra", key="btn_ptt", type="primary"):
            try:
                Ialim = ptt_Ialim if ptt_Ialim > 0 else None
                res = calcular_puesta_tierra(
                    voltaje_linea_neutro_v=ptt_V,
                    resistencia_tierra_ohm=ptt_R,
                    material_conductor=ptt_mat,
                    corriente_dispositivo_a=Ialim,
                    configuracion_electrodos=ptt_contexto,
                )
                _comp_guardar_en_elemento(nombre_elem, res)
                _comp_resultado(res)
                c1b, c2b, c3b = st.columns(3)
                with c1b: _comp_boton_articulo("Art. 250",     "art250",     "ptt_r1")
                with c2b: _comp_boton_articulo("Art. 250-52",  "art250-52",  "ptt_r2")
                with c3b: _comp_boton_articulo("Tabla 250-66", "tab250-66", "ptt_r3")
            except (ValueError, KeyError) as e:
                st.error(str(e))


