"""Vistas independientes de la aplicación."""
