import streamlit as st
CAIDA_TENSION_MAX_PCT = 3.0
RESISTENCIA_TIERRA_MAX_OHM = 5.0
from ui.components import _comp_boton_articulo

def _vista_manual() -> None:
    st.title("📘 Manual Técnico — NOM-001-SEDE-2012")
    st.caption("Referencia estructurada de la memoria técnica de instalaciones eléctricas.")

    secciones = [
        (1, "Portada y datos generales", ["Nombre del proyecto", "Ubicación", "Propietario", "Proyectista", "Fecha"], []),
        (2, "Marco normativo", ["NOM-001-SEDE-2012", "PEC-NOM-001", "Otras NOM aplicables"], []),
        (3, "Descripción del inmueble", ["Tipo de inmueble", "Niveles y superficie", "Uso principal"], []),
        (4, "Condiciones de diseño", ["Altitud y temperatura", "Sistema de suministro", "Nivel de tensión"], []),
        (5, "Cálculo de cargas", ["Inventario de cargas", "Demanda máxima", "Factor de demanda"],
         [("Art. 220", "art220"), ("Art. 220-12", "art220-12"), ("Art. 220-14", "art220-14")]),
        (6, "Alimentadores y conductores", ["Selección de calibre", "Caída de tensión", "Aislamiento", "Identificación"],
         [("Tabla 310-15", "tab310-15b16"), ("Art. 210-19", "art210-19"), ("Tabla 9", "tab9")]),
        (7, "Canalizaciones", ["EMT, IMC, PVC, charolas", "Factor de llenado", "Radios de curvatura"],
         [("Art. 358", "art358"), ("Art. 352", "art352"), ("Art. 392", "art392")]),
        (8, "Protecciones eléctricas", ["ITMs y fusibles", "Coordinación conductor-protección", "kAIC"],
         [("Art. 240", "art240"), ("Art. 240-6", "art240-6"), ("Art. 430", "art430")]),
        (9, "Puesta a tierra", ["Electrodos permitidos", "Conductores de tierra", "Pararrayos y SPDs"],
         [("Art. 250", "art250"), ("Art. 250-52", "art250-52"), ("Tabla 250-66", "tab250-66")]),
        (10, "Tableros eléctricos", ["Diagrama unifilar", "Cuadro de cargas", "Espacios libres"],
         [("Art. 408", "art408")]),
        (11, "Transformadores", ["Potencia y nivel de tensión", "Corriente nominal", "Protecciones"],
         [("Art. 450", "art450"), ("Art. 450-3", "art450-3")]),
        (12, "Sistemas especiales", ["Emergencia", "Bombas contra incendio", "Elevadores"],
         [("Art. 700", "art700"), ("Art. 695", "art695"), ("Art. 620", "art620")]),
        (13, "Diagramas eléctricos", ["Diagrama unifilar", "Planos de distribución"], []),
        (14, "Memorias de cálculo", ["Cargas", "Conductores", "Protecciones", "Caída de tensión"], []),
        (15, "Especificaciones técnicas", ["Materiales", "Normas de calidad", "Métodos de instalación"], []),
        (16, "Conclusiones", ["Cumplimiento normativo", "Firma y cédula profesional"], []),
    ]

    for num, titulo, items, arts in secciones:
        with st.expander(f"{num}. {titulo}", expanded=(num <= 2)):
            for item in items:
                st.markdown(f"- {item}")
            if arts:
                st.markdown("")
                cols = st.columns(len(arts))
                for col, (label, clave) in zip(cols, arts):
                    with col:
                        _comp_boton_articulo(label, clave, key_suffix=f"m{num}")


