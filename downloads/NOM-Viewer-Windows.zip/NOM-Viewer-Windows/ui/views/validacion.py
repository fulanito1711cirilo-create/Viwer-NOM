import streamlit as st
from core.reglas import evaluar_y_formatear, REGLAS_NOM_001
CAIDA_TENSION_MAX_PCT = 3.0
RESISTENCIA_TIERRA_MAX_OHM = 5.0

def _vista_validacion() -> None:
    st.title("✅ Validación Normativa")
    st.caption("Evalúa las reglas implementadas con los datos disponibles. No constituye una verificación completa ni certificación de la instalación.")

    elementos = st.session_state.elementos

    if not elementos:
        st.info("Aún no hay cálculos acumulados. Ve a **Calculadoras** y asigna los resultados a un elemento eléctrico.")
        return

    if not REGLAS_NOM_001:
        st.error("No se cargaron reglas de validación. Revisa la instalación de core/reglas.py.")
        return

    total_evaluadas = 0
    total_cumplidas = 0
    total_errores = 0
    total_advertencias = 0

    for nombre_el, calculos in elementos.items():
        st.subheader(f"⚡ {nombre_el}")
        for i, resultado in enumerate(calculos):
            datos_planos = resultado.valores
            if REGLAS_NOM_001:
                try:
                    resumen = evaluar_y_formatear(datos_planos, REGLAS_NOM_001)
                except Exception as e:
                    st.warning(f"No se pudo evaluar '{resultado.tipo}': {e}")
                    continue
                total_evaluadas += resumen.total_evaluadas
                total_cumplidas += resumen.total_cumplidas
                total_errores += resumen.total_errores
                total_advertencias += resumen.total_advertencias

                estado = "Sin reglas aplicables" if resumen.total_evaluadas == 0 else ("Sin errores en reglas evaluadas" if resumen.aprobado else "Errores en reglas evaluadas")
                st.markdown(f"**{resultado.tipo.replace('_',' ').title()}** — {estado}")
                if resumen.total_errores or resumen.total_advertencias:
                    for err in resumen.errores_criticos():
                        st.markdown(f"- ❌ {err.referencia}: {err.mensaje}")
                    for adv in resumen.advertencias_activas():
                        st.markdown(f"- ⚠️ {adv.referencia}: {adv.mensaje}")
            else:
                if resultado.cumple is True:
                    st.markdown(f"**{resultado.tipo.replace('_',' ').title()}** — ✓ CUMPLE")
                elif resultado.cumple is False:
                    st.markdown(f"**{resultado.tipo.replace('_',' ').title()}** — ✗ NO CUMPLE")
                else:
                    st.markdown(f"**{resultado.tipo.replace('_',' ').title()}** — ? Sin evaluar")
            st.markdown("---")

    st.divider()
    st.subheader("Resumen Global de Validación")
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Evaluaciones", total_evaluadas)
    col2.metric("Cumplidas", total_cumplidas)
    col3.metric("Errores", total_errores)
    col4.metric("Advertencias", total_advertencias)


