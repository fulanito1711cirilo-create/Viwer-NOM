import streamlit as st
from services.pdf_service import PDFNoCaregadoError as PDFNoCargadoError
from ui.state import obtener_pdf_service
CAIDA_TENSION_MAX_PCT = 3.0
RESISTENCIA_TIERRA_MAX_OHM = 5.0
from ui.components import _navegar_articulo, _comp_separador

from core.indice import _construir_indice_jerarquico, _filtrar_indice

def _renderizar_indice(indice: dict, prefijo: str = "") -> None:
    # Solo construir controles de la referencia seleccionada, no cientos de botones.
    opciones = [clave for tipo in indice.values() for base, info in tipo.items()
                for clave in ([base] if info["pagina"] is not None else []) + list(info["subs"])]
    if not opciones:
        st.info("No hay referencias que coincidan con la búsqueda.")
        return
    clave = st.selectbox("Artículo o tabla", sorted(opciones), key=f"{prefijo}_referencia")
    if st.button("Abrir referencia", key=f"{prefijo}_abrir"):
        _navegar_articulo(clave)


def _vista_visor() -> None:
    st.title("📄 Visor NOM-001-SEDE-2012")

    if not obtener_pdf_service().esta_cargado:
        st.warning("⚠️ Sube el PDF en el panel lateral para usar el visor.")
        st.info("Descarga la NOM-001-SEDE-2012 gratuitamente desde el DOF (dof.gob.mx).")
        return

    _consulta_estructurada()
    _herramientas_documento()
    total = obtener_pdf_service().total_paginas

    c1, c2, c3, c4, c5 = st.columns([1, 1, 3, 1, 1])
    with c1:
        if st.button("⏮", help="Primera página", key="v_prim"):
            st.session_state.pagina_pdf = 0
            st.rerun()
    with c2:
        if st.button("◀", help="Página anterior", key="v_ant"):
            st.session_state.pagina_pdf = obtener_pdf_service().pagina_anterior(st.session_state.pagina_pdf)
            st.rerun()
    with c3:
        pag_input = st.number_input(
            "Ir a página", min_value=1, max_value=total,
            value=st.session_state.pagina_pdf + 1, label_visibility="collapsed",
        )
        if int(pag_input) - 1 != st.session_state.pagina_pdf:
            st.session_state.pagina_pdf = int(pag_input) - 1
            st.rerun()
    with c4:
        if st.button("▶", help="Página siguiente", key="v_sig"):
            st.session_state.pagina_pdf = obtener_pdf_service().pagina_siguiente(st.session_state.pagina_pdf)
            st.rerun()
    with c5:
        if st.button("⏭", help="Última página", key="v_ult"):
            st.session_state.pagina_pdf = total - 1
            st.rerun()

    zoom = st.select_slider(
        "Zoom", options=[0.75, 1.0, 1.5, 2.0, 2.5, 3.0],
        value=st.session_state.zoom_pdf, key="v_zoom",
    )
    st.session_state.zoom_pdf = zoom
    st.caption(f"Página {st.session_state.pagina_pdf + 1} de {total}")

    arts_pagina = obtener_pdf_service().articulos_en_pagina(st.session_state.pagina_pdf)
    if arts_pagina:
        arts_html = " ".join(f'<span class="art-tag">{a}</span>' for a in arts_pagina)
        st.markdown(arts_html, unsafe_allow_html=True)

    try:
        pagina = obtener_pdf_service().renderizar_pagina(st.session_state.pagina_pdf, zoom=zoom)
        st.image(pagina.imagen, use_container_width=True)
    except PDFNoCargadoError:
        st.error("PDF no disponible. Vuelve a subirlo.")
    except Exception as e:
        st.error(f"Error al renderizar: {e}")

    st.divider()

    modo_opciones = {"Navegación Rápida": "rapida", "Índice Completo": "completo"}
    modo_actual = st.radio(
        "Modo de navegación:",
        list(modo_opciones.keys()),
        horizontal=True,
        key="visor_modo_nav",
    )
    st.divider()

    if modo_actual == "Navegación Rápida":
        _comp_separador("Navegación Rápida")
        categorias_nav = {
            "Cargas":             ["art220", "art220-12", "art220-14", "art220-52",
                                   "tab220-12", "tab220-3", "tab220-42"],
            "Conductores":        ["art310", "tab310-15b16", "tab310-15b2b",
                                   "tab310-15b3a", "tab9", "art210-19", "art215-2"],
            "Protecciones":       ["art240", "art240-6", "art240-4",
                                   "art430", "art430-52", "tab430-52"],
            "Tierra":             ["art250", "art250-52", "art250-50",
                                   "tab250-66", "tab250-122", "tab250-3"],
            "Canalizaciones":     ["art358", "art352", "art392", "art342",
                                   "art344", "art366", "cap9tablas"],
            "Transformadores":    ["art450", "art450-3", "art450-2",
                                   "tab450-3a", "tab450-3b"],
            "Motores":            ["art430", "art430-24", "art430-25",
                                   "art430-31", "art430-32", "tab430-10"],
            "Emergencia":         ["art700", "art695", "art620",
                                   "art701", "art702"],
            "Fotovoltaico":       ["art690", "art690-7", "art690-8",
                                   "art690-9", "art690-31", "tab690-7"],
            "Tableros":           ["art408", "art409", "art404",
                                   "art110-26", "tab408-5"],
            "Acometidas":         ["art230", "art225", "art215",
                                   "art215-2", "art215-3"],
            "Areas Clasificadas": ["art500", "art501", "art502",
                                   "art503", "art516"],
        }

        for cat, claves in categorias_nav.items():
            with st.expander(cat):
                cols = st.columns(4)
                for i, clave in enumerate(claves):
                    with cols[i % 4]:
                        key_unica = f"vnav_{cat}_{clave}"
                        if st.button(clave, key=key_unica, use_container_width=True):
                            _navegar_articulo(clave)
    else:
        _comp_separador("Índice Completo")
        st.caption("Estructura jerárquica de la NOM-001-SEDE-2012 generada desde el MAPA")
        texto_busqueda = st.text_input("🔍 Buscar artículo o tabla (escribe parte de la clave)", key="buscar_indice")
        indice_completo = _construir_indice_jerarquico(obtener_pdf_service().mapa_articulos)
        indice_mostrado = _filtrar_indice(indice_completo, texto_busqueda)
        _renderizar_indice(indice_mostrado, prefijo="indice")




def _herramientas_documento():
    from ui.state import ruta_pdf
    from services.search_service import SearchService
    svc = obtener_pdf_service()
    with st.expander("🔎 Buscar en el documento", expanded=False):
        with st.form("buscar_texto_pdf"):
            texto = st.text_input("Palabras de la NOM", key="consulta_pdf", placeholder="puesta a tierra")
            buscar = st.form_submit_button("Buscar en el PDF")
        if buscar:
            path = ruta_pdf().with_suffix('.sqlite')
            if path.is_file():
                try:
                    st.session_state.busqueda_resultados = SearchService(path, svc.document_id).buscar(texto)
                except ValueError:
                    st.session_state.busqueda_resultados = []
                    st.warning("Este PDF no tiene un índice de búsqueda preparado.")
            else:
                st.info("Todavía no se ha preparado el índice de este documento.")
        resultados = st.session_state.busqueda_resultados
        for item in resultados:
            st.caption(item['texto'])
            if st.button(f"Abrir página {item['pagina'] + 1}", key=f"resultado_{item['pagina']}"):
                st.session_state.pagina_pdf = item['pagina']
                st.rerun()
        if buscar and not resultados:
            st.info("No hay coincidencias disponibles para esta consulta.")
        if len(resultados) == 20:
            st.caption("Se muestran las primeras 20 páginas; agrega palabras para precisar la búsqueda.")
    with st.expander("⭐ Mis páginas marcadas"):
        pagina = st.session_state.pagina_pdf
        marcadores = st.session_state.marcadores
        if st.button("Marcar esta página", key="marcar_pagina") and pagina not in marcadores:
            marcadores.append(pagina)
        if marcadores:
            elegida = st.selectbox("Páginas guardadas", sorted(marcadores), format_func=lambda p: f"Página {p + 1}")
            c1, c2 = st.columns(2)
            if c1.button("Ir a página marcada"):
                st.session_state.pagina_pdf = elegida
                st.rerun()
            if c2.button("Quitar marcador"):
                marcadores.remove(elegida)
                st.rerun()


@st.cache_resource
def _corpus_local(path, modificado):
    from services.nom_corpus import NOMCorpus
    return NOMCorpus(path)


def _consulta_estructurada():
    from ui.state import ruta_pdf
    path = ruta_pdf()
    if not path.with_suffix('.sqlite').is_file():
        return
    with st.expander("📖 Texto normativo y estructura"):
        try:
            corpus = _corpus_local(str(path), path.with_suffix('.sqlite').stat().st_mtime_ns)
            if corpus.sha256 != obtener_pdf_service().document_id:
                st.info("La lectura estructurada corresponde al documento incluido. Este PDF requiere su propio índice.")
                return
            with st.form('consulta_disposicion'):
                clave = st.text_input('Artículo o sección', placeholder='art250-52', key='unidad_clave')
                consultar = st.form_submit_button('Leer disposición')
            if consultar:
                # Validar antes de sustituir una consulta anterior.
                corpus.estructura(clave)
                st.session_state.unidad_lectura = {'clave':clave.strip().lower(), 'offset':0}
            consulta = st.session_state.get('unidad_lectura')
            if consulta:
                bloque = corpus.leer_disposicion(consulta['clave'],consulta['offset'])
                st.markdown(f"**{bloque['titulo']}**")
                st.caption('Extracción automática, pendiente de revisión técnica. Páginas físicas del PDF.')
                if bloque['motivos_revision']:
                    st.warning('Esta unidad requiere revisar sus límites: ' + ', '.join(bloque['motivos_revision']))
                for fragmento in bloque['fragmentos']:
                    st.caption(f"Página {fragmento['cita']['pagina_pdf']} · caracteres {fragmento['offset_inicio']}–{fragmento['offset_fin']}")
                    st.text(fragmento['texto'])
                if bloque['siguiente_desplazamiento'] is not None:
                    if st.button('Continuar lectura', key='continuar_disposicion'):
                        consulta['offset'] = bloque['siguiente_desplazamiento']
                        st.rerun()
                else:
                    st.caption('Fin del segmento delimitado automáticamente.')
                if bloque['hijos']:
                    st.caption('Secciones: ' + ', '.join(bloque['hijos']))
        except ValueError as exc:
            st.warning(str(exc))
