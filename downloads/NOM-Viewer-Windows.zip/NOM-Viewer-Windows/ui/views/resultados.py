from services.report_service import exportar_resultados
import streamlit as st
CAIDA_TENSION_MAX_PCT = 3.0
RESISTENCIA_TIERRA_MAX_OHM = 5.0
from ui.components import _comp_resultado

def _vista_resultados_acumulados() -> None:
    st.title("📋 Resultados Acumulados de Cálculo")
    st.caption("Todos los cálculos organizados por elemento eléctrico.")

    _archivo_proyecto()
    elementos = st.session_state.elementos

    if not elementos:
        st.info("No hay resultados acumulados. Ve a **Calculadoras** y asigna cada cálculo a un elemento eléctrico.")
        return

    for nombre_el, calculos in elementos.items():
        with st.expander(f"⚡ {nombre_el} ({len(calculos)} cálculo(s))"):
            for resultado in calculos:
                _comp_resultado(resultado)

    if st.button("📄 Exportar PDF de Resultados", type="primary", key="exportar_pdf"):
        try:
            pdf_bytes = exportar_resultados(elementos, st.session_state.proyecto_nombre)

            st.download_button(
                label="⬇ Descargar PDF",
                data=pdf_bytes,
                file_name="Resultados_NOM001.pdf",
                mime="application/pdf",
                key="dl_resultados",
            )
        except ImportError:
            st.error("Instala fpdf2: `pip install fpdf2`")
        except Exception as exc:
            st.error(f"Error al generar PDF: {exc}")




def _archivo_proyecto():
    from services.project_service import cargar_proyecto, exportar_proyecto
    from ui.state import obtener_pdf_service
    with st.expander('💾 Guardar o recuperar proyecto'):
        archivo = st.file_uploader('Abrir proyecto NOM Viewer (.json)',type=['json'],key='archivo_proyecto')
        if st.button('Cargar y recalcular proyecto',disabled=archivo is None,key='cargar_proyecto'):
            try:
                proyecto = cargar_proyecto(archivo.getvalue(),obtener_pdf_service().document_id)
                st.session_state.elementos = proyecto['elementos']
                st.session_state.proyecto_nombre = proyecto['nombre']
                st.session_state.resultados = {}
                st.session_state.datos_evaluacion = {}
                for resultados in proyecto['elementos'].values():
                    for resultado in resultados:
                        st.session_state.resultados[resultado.tipo] = resultado
                        st.session_state.datos_evaluacion.update(resultado.valores)
                st.session_state.proyecto_resumen = f"{proyecto['calculos']} cálculos recalculados; {proyecto['resultados_distintos']} resultados difieren del archivo recibido."
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))
        st.text_input('Nombre del proyecto',key='proyecto_nombre',max_chars=200)
        if st.session_state.get('proyecto_resumen'):
            st.info(st.session_state.proyecto_resumen)
        st.caption('El proyecto se conserva en el archivo descargado. Al cargarlo se sustituyen los resultados de esta sesión y se recalculan con el motor actual.')
        if st.session_state.elementos:
            try:
                contenido = exportar_proyecto(st.session_state.proyecto_nombre,st.session_state.elementos,obtener_pdf_service().document_id)
                st.download_button('Guardar proyecto JSON',contenido,'Proyecto_NOM.json','application/json',key='guardar_proyecto')
            except ValueError as exc:
                st.warning(str(exc))
