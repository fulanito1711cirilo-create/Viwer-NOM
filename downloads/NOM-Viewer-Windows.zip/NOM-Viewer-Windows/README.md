# NOM Viewer · Streamlit y MCP

Consulta documental y herramientas de cálculo para NOM-001-SEDE-2012. Motor 0.2.0.
Las evaluaciones implementadas son parciales y están pendientes de revisión profesional.

## Ejecutar

Python 3.12 recomendado. Desde la raíz del repositorio:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

En la nube preparada: `/workspace/.venvs/nom/bin/python`.
Para conectar agentes: instalar también `requirements-mcp.txt` y consultar
[la configuración MCP](docs/MCP.md). No requiere claves de IA ni base de datos externa.

## PDF e índices

El PDF proporcionado por el usuario está instalado en esta nube en `data/NOM.pdf`
(1140 páginas). SHA-256:
`f687753a9368ccdf88833975ae9c9c0c9f8d5908e9d8a711020778ac87f8ce6d`.
No hace falta Drive. El enlace original del proyecto es
https://drive.google.com/file/d/1pD823-cEUWY1tPMqJYO96YQxuE9v3FgX/view

El PDF y el SQLite no se versionan en Git. En otra máquina hay que aportar el PDF:

```bash
python scripts/index_document.py data/NOM.pdf
```

Se generan `NOM.sqlite`, `NOM.references.json` y `NOM.audit.json` junto al archivo.
`NOM_PDF_PATH` permite configurar otra ruta; sus índices deben generarse allí.
La búsqueda y los fragmentos están vinculados al SHA-256. Cambiar el PDF invalida
el corpus activo: regenerar y reiniciar. La carga de PDF no realiza descargas de red.

## Capacidades

- Lectura visual y textual de páginas, búsqueda local sin acentos y marcadores por sesión.
- Corpus estructurado de 150 artículos y 2714 secciones, con offsets y citas por página.
- Detección de encabezados con contexto de artículo y evidencia tipográfica; 33 citas
  descartadas como falsos encabezados permanecen conservadas en el texto original.
- Incisos, notas y excepciones candidatos; jerarquía padre/hijos y auditoría reproducible.
- Cinco tablas estructuradas contrastadas contra el texto y la imagen del PDF:
  ampacidad de 75 °C, corrección térmica base 30 °C, agrupamiento, Tabla 9 y Tabla 250-122.
- Seis calculadoras con entradas y versión del motor, fuentes donde se han contrastado datos.
- Proyectos JSON descargables que se recalculan al abrirlos; memorias PDF con desarrollo y citas.
- MCP con 16 herramientas documentales, tablas y cálculos; transporte local stdio.

El reporte actual no detecta claves de unidad repetidas ni límites pendientes según
las heurísticas. Esto no equivale a revisión humana ni garantiza cobertura semántica.
Las tablas no estructuradas requieren consultar su disposición visual en el PDF.

## Proyectos y memorias

En «Resultados acumulados» abre «Guardar o recuperar proyecto». Descarga el JSON
para conservar tu trabajo; no hay persistencia automática multiusuario en servidor.
Al abrir un archivo, se valida formato, tamaño, documento y funciones admitidas,
y se recalculan sus entradas con el motor actual. Los resultados recibidos nunca
se utilizan como resultados vigentes; se informa si difieren de los recalculados.
La carga sustituye los cálculos de la sesión: guarda primero el proyecto anterior.

Límites del formato 1: 2 MiB, 100 elementos y 500 cálculos. El informe PDF incluye
entradas, valores, unidades, desarrollo, advertencias, versión y fuentes disponibles.
Se transliteran símbolos técnicos como Ω → ohm para conservar su significado en
Helvetica; otros caracteres no admitidos por Latin-1 se sustituyen.

## Arquitectura

| Capa | Ubicación |
| --- | --- |
| Entrada y rutas | `app.py` |
| Vistas, componentes y sesión | `ui/` |
| Fórmulas, reglas, estructura y tablas | `core/` |
| Datos y procedencia de las tablas | `config/normas/tablas_75c.json` |
| PDF, búsqueda, corpus, proyectos y memorias | `services/` |
| Transporte MCP | `mcp_server.py` |
| Generación de índices y extracción de Tabla 9 | `scripts/` |

Añadir primero la lógica en `core`, probarla y después agregar controles o herramientas.
Los servicios no deben importar Streamlit. Los documentos mutables son privados por
sesión. La base normativa se consulta en lectura, sin credenciales ni acceso a red.

## Verificación y rendimiento

```bash
pip install -r requirements-mcp.txt
python -m unittest discover -v
python scripts/benchmark.py
```

La suite comprueba fronteras de las tablas, entradas inválidas, citas, límites de
segmentos, renderizado, proyectos, memoria PDF, vistas y cliente MCP real. Las pruebas
específicas del PDF real se omiten cuando no está instalado. El test MCP utiliza un
PDF sintético cuando el real no está disponible. En esta nube, la prueba de procesos
asíncronos necesita la elevación admitida por el sandbox; tiene límite de 20 segundos.

`.github/workflows/tests.yml` prepara estas pruebas en Python 3.12; su ejecución en
GitHub queda pendiente hasta subir los cambios. El benchmark es sintético, no mide
concurrencia ni latencia completa de usuario. La caché LRU guarda hasta 25 imágenes
PNG o 32 MiB por sesión y distingue página/zoom. Cada imagen tiene un límite aproximado
de 8 megapíxeles. El documento original permanece en memoria por sesión.

## Alcance técnico

Ver [el registro de correcciones y pendientes](docs/REVISION_TECNICA.md).
No se declara certificación de instalaciones, vigencia de la edición ni una revisión
completa de las fórmulas. La selección general de motores/transformadores y el cálculo
de demanda siguen requiriendo parámetros y procedimientos específicos. Las reglas
sin datos o sin contexto se omiten y nunca se consideran una aprobación completa.

## Publicación remota

`http_server.py` ofrece MCP Streamable HTTP en `/mcp` y salud en `/healthz`.
La imagen Docker incluye el PDF y genera sus índices durante el build; funciona
como usuario sin privilegios y con el sistema de archivos de solo lectura.
Está preparada la configuración de Render en `render.yaml`. Ver
[publicación y requisitos del alojamiento](docs/DEPLOYMENT.md).

El transporte HTTP está probado localmente. La URL pública todavía requiere
crear el servicio en un alojamiento autorizado; arrancar un puerto local no lo publica.

## Usar una PC con Windows

Consultar `LEEME-WINDOWS.txt`. Los accesos `01_Instalar.cmd`, `02_Publicar_MCP.cmd`,
`03_Abrir_Visor.cmd`, `04_MCP_Solo_Local.cmd` y `05_Probar_MCP.cmd` preparan y ejecutan
la aplicación con Python 3.12. Un Quick Tunnel permite pruebas públicas temporales
sin cuenta Render. Para un agente que viva en la misma PC, usar la configuración
stdio generada en `.local/windows/mcp-config.json`, sin publicar nada.
