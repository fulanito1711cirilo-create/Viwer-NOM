import json
import unittest
from core.calculos import calcular_caida_tension
from services.project_service import exportar_proyecto, cargar_proyecto, LIMITE_BYTES


class ProjectTests(unittest.TestCase):
    def setUp(self):
        self.resultado = calcular_caida_tension('Trifásico','cobre','PVC','10',50,20,220,.85)
        self.contenido = exportar_proyecto('Instalación A',{'Alimentador':[self.resultado]},'firma')

    def test_roundtrip_reproduce_entradas_unidades_y_fuente(self):
        proyecto=cargar_proyecto(self.contenido,'firma')
        self.assertEqual(proyecto['resultados_distintos'],0)
        nuevo=proyecto['elementos']['Alimentador'][0]
        self.assertEqual(nuevo.entradas,self.resultado.entradas)
        self.assertEqual(nuevo.fuentes,self.resultado.fuentes)
        self.assertEqual(nuevo.valores,self.resultado.valores)
        self.assertEqual(nuevo.entradas['conductores_por_fase'],1)

    def test_no_confia_en_resultados_importados(self):
        datos=json.loads(self.contenido)
        datos['elementos']['Alimentador'][0]['resultado_registrado']['valores']['caida_v']=999
        proyecto=cargar_proyecto(json.dumps(datos).encode(),'firma')
        self.assertEqual(proyecto['resultados_distintos'],1)
        self.assertNotEqual(proyecto['elementos']['Alimentador'][0].valores['caida_v'],999)

    def test_rechaza_otro_documento_y_funciones_no_permitidas(self):
        with self.assertRaises(ValueError):cargar_proyecto(self.contenido,'otro')
        datos=json.loads(self.contenido)
        datos['elementos']['Alimentador'][0]['funcion']='__import__'
        with self.assertRaises(ValueError):cargar_proyecto(json.dumps(datos).encode(),'firma')

    def test_rechaza_archivos_invalidos_y_argumentos_inesperados(self):
        for contenido in [b'{',b'[]',b'{"x":1,"x":2}',b'{"n":NaN}',b' '*(LIMITE_BYTES+1)]:
            with self.assertRaises(ValueError):cargar_proyecto(contenido,'firma')
        datos=json.loads(self.contenido)
        datos['elementos']['Alimentador'][0]['entradas']['opcion_inesperada']='valor'
        with self.assertRaises(ValueError):cargar_proyecto(json.dumps(datos).encode(),'firma')

    def test_memoria_pdf_conserva_entradas_unidades_y_citas(self):
        import pymupdf
        from services.report_service import exportar_resultados
        contenido=exportar_resultados({'Alimentador':[self.resultado]},'Instalación A')
        with pymupdf.open(stream=contenido,filetype='pdf') as pdf:
            texto=''.join(p.get_text() for p in pdf)
        for esperado in ['Instalación A','Entradas','longitud_m: 50','Resultados','R_ohm_km: 3.9 ohm/km','pagina PDF 1011',self.resultado.fuentes[0]['sha256']]:
            self.assertIn(esperado,texto)
