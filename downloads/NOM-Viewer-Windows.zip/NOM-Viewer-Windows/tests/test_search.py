import hashlib
from pathlib import Path
import tempfile
import unittest
import pymupdf
from scripts.index_document import generar
from services.search_service import SearchService


class SearchTests(unittest.TestCase):
    def test_busqueda_y_firma_documento(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'doc.pdf'
            with pymupdf.open() as doc:
                doc.new_page().insert_text((30, 50), 'Proteccion de puesta a tierra')
                doc.new_page().insert_text((30, 50), 'Conductores electricos')
                doc.save(path)
            generar(path)
            svc = SearchService(path.with_suffix('.sqlite'), hashlib.sha256(path.read_bytes()).hexdigest())
            self.assertEqual(svc.buscar('puesta tierra')[0]['pagina'], 0)
            self.assertEqual(svc.buscar('eléctricos')[0]['pagina'], 1)
            self.assertEqual(svc.buscar('" - *'), [])
            self.assertEqual(svc.buscar('inexistente'), [])
            with self.assertRaises(ValueError):
                SearchService(path.with_suffix('.sqlite'), 'otro').buscar('tierra')
