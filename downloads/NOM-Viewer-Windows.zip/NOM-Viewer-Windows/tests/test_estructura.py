import unittest
from core.estructura import segmentar


class EstructuraTests(unittest.TestCase):
    def test_limites_entre_paginas_e_incisos(self):
        paginas = ['ARTÍCULO 250\nTIERRA\n250-1. Alcance.\na) Regla uno\n',
                   'EXCEPCIÓN: conservar esta condición.\n1) Detalle\n250-2. Otra regla.\n',
                   'ARTÍCULO 280\nPROTECCIÓN\n280-1. Alcance.\n']
        unidades, reporte = segmentar(paginas)
        indice = {u['clave']:u for u in unidades}
        texto = ''.join(paginas)
        u = indice['art250-1']
        contenido = texto[u['inicio']:u['fin']]
        self.assertIn('EXCEPCIÓN', contenido)
        self.assertNotIn('250-2.', contenido)
        self.assertEqual(u['padre'], 'art250')
        self.assertEqual(u['pagina_fin'], 1)
        self.assertEqual([n['etiqueta'] for n in u['subdivisiones']], ['a', 'EXCEPCIÓN', '1'])
        self.assertEqual(texto[indice['art250']['inicio']:indice['art250']['fin']], ''.join(paginas[:2]))
        self.assertFalse(u['revision_humana'])
        self.assertIn('limite_final_no_confirmado', indice['art280-1']['motivos'])

    def test_repeticiones_no_se_presentan_como_verificadas(self):
        unidades, reporte = segmentar(['ARTÍCULO 250\n250-1. Uno\n250-2. Dos\n250-2. Repetido\nARTÍCULO 280\n'])
        self.assertIn('art250-2', reporte['claves_repetidas'])
        self.assertIn('limite_siguiente_ambiguo', unidades[1]['motivos'])
        self.assertTrue(all(u['estado']=='requiere_revision' for u in unidades if u['clave']=='art250-2'))

    def test_referencia_fuera_del_articulo_no_es_confiable(self):
        unidades, _ = segmentar(['ARTÍCULO 250\n250-1. Regla\n310-15. Cita fuera de contexto\nARTÍCULO 280\n'])
        incorrecta = next(u for u in unidades if u['clave']=='art310-15')
        self.assertIn('encabezado_fuera_de_su_articulo', incorrecta['motivos'])

    def test_tipografia_y_contexto_descartan_citas_sin_borrar_texto(self):
        pagina='ARTÍCULO 250\n250-1. Alcance\n250-2. referencia en texto normal\n250-3. Tercer encabezado\nCAPÍTULO 10\nTABLAS\n'
        evidencias={0:[{'texto':'250-1. Alcance','negrita':True}, {'texto':'250-2. referencia','negrita':False}, {'texto':'250-3. Tercer','negrita':True}]}
        unidades,reporte=segmentar([pagina],evidencias)
        self.assertNotIn('art250-2',[u['clave'] for u in unidades])
        u=next(u for u in unidades if u['clave']=='art250-1')
        self.assertIn('250-2. referencia',pagina[u['inicio']:u['fin']])
        articulo=next(u for u in unidades if u['clave']=='art250')
        self.assertNotIn('CAPÍTULO 10',pagina[articulo['inicio']:articulo['fin']])
        self.assertFalse(articulo['motivos'])
        self.assertEqual(reporte['candidatos_descartados'][0]['razon'],'cita_en_texto_normal')

    def test_corpus_rechaza_encabezados_ambiguos_incluso_con_negrita(self):
        import tempfile
        from pathlib import Path
        import pymupdf
        from scripts.index_document import generar
        from services.nom_corpus import NOMCorpus
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'doc.pdf'
            with pymupdf.open() as pdf:
                pagina=pdf.new_page()
                for y,texto in [(50,'ARTÍCULO 250'),(70,'250-1. Primer encabezado'),(90,'250-1. Segundo encabezado'),(110,'ARTÍCULO 280')]:
                    pagina.insert_text((30,y),texto,fontname='hebo')
                pdf.save(path)
            generar(path)
            with self.assertRaisesRegex(ValueError,'ambiguo'):
                NOMCorpus(path).leer_disposicion('art250-1')
