import json
from pathlib import Path
import unittest
from ui.state import crear_servicio, ruta_pdf
from services.search_service import SearchService


@unittest.skipUnless(ruta_pdf().is_file() and ruta_pdf().with_suffix('.sqlite').is_file(), 'PDF e índice local opcionales no instalados')
class DocumentoRealTests(unittest.TestCase):
    def test_referencias_reales_y_busqueda(self):
        svc = crear_servicio(ruta_pdf().read_bytes())
        self.assertEqual(svc.total_paginas, 1140)
        for clave, pagina in {'art110':27, 'art250':116, 'art310':180, 'art430':402, 'tab310-15b16':189}.items():
            self.assertEqual(svc.pagina_de_articulo(clave), pagina)
        for pagina in [0, 116, 189, 1139]:
            self.assertTrue(svc.renderizar_pagina(pagina).imagen.startswith(b'\x89PNG'))
        self.assertTrue(SearchService(ruta_pdf().with_suffix('.sqlite'),svc.document_id).buscar('puesta a tierra'))
        svc.close()

    def test_lectura_estructurada_en_el_visor(self):
        from streamlit.testing.v1 import AppTest
        at = AppTest.from_file(str(Path(__file__).resolve().parents[1] / 'app.py')).run()
        at.sidebar.radio[0].set_value('📄 Visor NOM').run()
        at.text_input(key='unidad_clave').set_value('art250-52')
        at.button(key='FormSubmitter:consulta_disposicion-Leer disposición').click().run()
        self.assertFalse(at.exception)
        self.assertTrue(any('250-52.' in texto.value for texto in at.text))
