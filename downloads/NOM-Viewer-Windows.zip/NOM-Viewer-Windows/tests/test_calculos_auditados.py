"""Casos de contraste con las páginas 186, 187 y 190 del PDF identificado."""
import math
import unittest
from core.calculos import seleccionar_calibre, seleccionar_proteccion, calcular_caida_tension
from core.tablas import factor_temperatura_75, factor_agrupamiento, consultar_tabla


class CalculosAuditadosTests(unittest.TestCase):
    def test_fronteras_temperatura_base_30_columna_75(self):
        for t, esperado in [(10,1.20),(11,1.15),(20,1.11),(21,1.05),(25,1.05),(26,1),(30,1),
                            (30.1,.94),(35,.94),(36,.88),(40,.88),(41,.82),(60,.58),(61,.47),(65,.47),(66,.33),(70,.33)]:
            with self.subTest(t=t):
                self.assertEqual(factor_temperatura_75(t),esperado)
        for t in [70.1,float('nan'),float('inf')]:
            with self.assertRaises(ValueError):factor_temperatura_75(t)

    def test_fronteras_agrupamiento(self):
        for n,f in [(1,1),(3,1),(4,.8),(6,.8),(7,.7),(9,.7),(10,.5),(20,.5),(21,.45),(30,.45),(31,.4),(40,.4),(41,.35),(100,.35)]:
            self.assertEqual(factor_agrupamiento(n),f)
        for n in [0,-1,2.5,True]:
            with self.assertRaises(ValueError):factor_agrupamiento(n)

    def test_aluminio_usa_columna_real_no_porcentaje_cobre(self):
        r=seleccionar_calibre(60,1,220,'Trifásico','aluminio','PVC')
        self.assertEqual(r.valores['calibre_ampacidad'],'4')
        self.assertEqual(r.valores['ampacidad_base_a'],65)
        self.assertEqual(r.fuentes[0]['pagina_pdf'],190)
        tabla=consultar_tabla('tab310-15b16')['datos']
        self.assertEqual(tabla['aluminio']['6'],50)
        self.assertNotIn('8',tabla['aluminio'])
        self.assertFalse(r.revision_profesional)

    def test_paralelos_aplican_corriente_por_conductor(self):
        r=seleccionar_calibre(200,1,220,'Trifásico','cobre','PVC',num_conductores_canaliz=6,conductores_por_fase=2)
        self.assertEqual(r.valores['calibre_final'],'1/0')
        self.assertEqual(r.valores['ampacidad_corregida_a'],240)
        with self.assertRaises(ValueError):
            seleccionar_calibre(20,1,220,'Trifásico','cobre','PVC',conductores_por_fase=0)

    def test_no_aprueba_proteccion_sin_coordinacion_o_capacidad(self):
        self.assertIsNone(seleccionar_proteccion('General',20,10).cumple)
        with self.assertRaises(ValueError):seleccionar_proteccion('General',20,201)
        with self.assertRaises(ValueError):seleccionar_proteccion('General',float('nan'),10)
        with self.assertRaises(ValueError):calcular_caida_tension('Trifásico','cobre','PVC','10',10,20,220,.85,1.5)

    def test_resistencia_aluminio_no_se_inventa_desde_cobre(self):
        tabla=consultar_tabla('tab9')['datos']
        self.assertEqual(tabla['aluminio']['6']['PVC']['R'],2.66)
        self.assertEqual(tabla['aluminio']['3']['Aluminio']['R'],1.35)
        self.assertEqual(tabla['cobre']['1/0']['Aluminio']['R'],.43)
        self.assertEqual(tabla['cobre']['750']['Acero']['X'],.157)
        r=calcular_caida_tension('Trifásico','aluminio','PVC','6',50,20,220,1)
        esperado=math.sqrt(3)*20*.05*2.66
        self.assertAlmostEqual(r.valores['caida_v'],esperado,places=4)
        self.assertEqual(r.fuentes[0]['pagina_pdf'],1011)
        with self.assertRaises(ValueError):
            calcular_caida_tension('Trifásico','aluminio','PVC','14',50,20,220,1)

    def test_tierra_no_equipara_resistencia_con_conformidad(self):
        from core.calculos import calcular_puesta_tierra
        from core.tablas import dimensionar_tierra_equipos
        a=calcular_puesta_tierra(127,40,'Cobre')
        self.assertIsNone(a.cumple)
        self.assertEqual(a.valores['requiere_electrodo_adicional'],-1)
        self.assertIn('No determinado',a.valores['calibre_tierra_equipos'])
        b=calcular_puesta_tierra(127,40,'Cobre',corriente_dispositivo_a=400,configuracion_electrodos='unico_varilla_tuberia_placa')
        self.assertEqual(b.valores['calibre_tierra_equipos'],'2 AWG')
        self.assertEqual(b.valores['requiere_electrodo_adicional'],1)
        self.assertIsNone(b.cumple)
        c=calcular_puesta_tierra(127,25,'Cobre',configuracion_electrodos='unico_varilla_tuberia_placa')
        self.assertEqual(c.valores['requiere_electrodo_adicional'],0)
        with self.assertRaises(ValueError):dimensionar_tierra_equipos(20,'Aluminio')
        with self.assertRaises(ValueError):dimensionar_tierra_equipos(6001)

    def test_motor_de_reglas_no_aprueba_cero_evaluaciones(self):
        from core.reglas import evaluar_y_formatear
        vacio=evaluar_y_formatear({})
        self.assertFalse(vacio.aprobado)
        self.assertEqual(vacio.cumplimiento_pct,0)
        sin_contexto=evaluar_y_formatear({'resistencia_tierra_ohm':40})
        self.assertEqual(sin_contexto.total_evaluadas,0)
        con_contexto=evaluar_y_formatear({'resistencia_tierra_ohm':40,'configuracion_electrodos':'unico_varilla_tuberia_placa'})
        self.assertEqual(con_contexto.total_errores,0)
        self.assertEqual(con_contexto.total_advertencias,1)

    def test_estimaciones_incompletas_no_certifican_motores_y_transformadores(self):
        from core.calculos import dimensionar_transformador
        self.assertIsNone(seleccionar_proteccion('Motor',20,10,100).cumple)
        self.assertIsNone(seleccionar_proteccion('Transformador',20,10,100).cumple)
        r=dimensionar_transformador(30,13200,220,'Trifásico')
        self.assertIsNone(r.cumple)
        self.assertNotIn('prot_primaria_max_a',r.valores)
        self.assertIn('referencia_125_primario_a',r.valores)
