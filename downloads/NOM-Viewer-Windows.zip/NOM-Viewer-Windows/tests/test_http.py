import asyncio
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import httpx
import pymupdf
from starlette.testclient import TestClient
from http_server import crear_app, configuracion_seguridad, LimitesPublicos
from mcp_server import corpus
from scripts.index_document import generar


class HTTPTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        pdf=Path(tmp.name)/'nom.pdf'
        with pymupdf.open() as doc:
            p=doc.new_page()
            p.insert_text((30,50),'ARTÍCULO 250',fontname='hebo')
            p.insert_text((30,70),'250-52. Electrodos de puesta a tierra.',fontname='hebo')
            p.insert_text((30,90),'Regla de puesta a tierra.')
            p.insert_text((30,110),'ARTÍCULO 280',fontname='hebo')
            doc.save(pdf)
        generar(pdf)
        parche=patch.dict(os.environ,{'NOM_PDF_PATH':str(pdf),'MCP_REQUESTS_PER_MINUTE':'300','MCP_MAX_CONCURRENT':'8'})
        parche.start()
        self.addCleanup(parche.stop)
        corpus.cache_clear()
        self.addCleanup(corpus.cache_clear)

    def test_inicializacion_herramientas_y_consulta_http(self):
        with TestClient(crear_app(),base_url='http://localhost') as client:
            self.assertEqual(client.get('/healthz').json()['status'],'ok')
            headers={'Accept':'application/json, text/event-stream'}
            inicio=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'test','version':'1'}}})
            self.assertEqual(inicio.status_code,200,inicio.text)
            tools=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':2,'method':'tools/list'})
            self.assertEqual(len(tools.json()['result']['tools']),16)
            result=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'buscar_nom','arguments':{'consulta':'puesta a tierra'}}})
            self.assertFalse(result.json()['result'].get('isError',False))
            self.assertIn('puesta',result.text.lower())

    def test_rechaza_host_origen_y_cuerpo_excesivo(self):
        with TestClient(crear_app(),base_url='http://localhost') as client:
            headers={'Accept':'application/json, text/event-stream'}
            payload={'jsonrpc':'2.0','id':1,'method':'tools/list'}
            self.assertEqual(client.post('/mcp',headers={**headers,'Host':'ajeno.example'},json=payload).status_code,421)
            self.assertEqual(client.post('/mcp',headers={**headers,'Origin':'https://ajeno.example'},json=payload).status_code,403)
            self.assertEqual(client.post('/mcp',headers={**headers,'Content-Type':'application/json'},content=' '*70000).status_code,413)

    def test_host_publico_y_origen_chatgpt(self):
        with patch.dict(os.environ,{'MCP_PUBLIC_URL':'https://nom.example.org'}):
            with TestClient(crear_app(),base_url='https://nom.example.org') as client:
                respuesta=client.post('/mcp',headers={'Accept':'application/json, text/event-stream','Origin':'https://chatgpt.com'},json={'jsonrpc':'2.0','id':1,'method':'tools/list'})
                self.assertEqual(respuesta.status_code,200,respuesta.text)
                self.assertEqual(len(respuesta.json()['result']['tools']),16)

    def test_cuota_responde_con_reintento(self):
        with patch.dict(os.environ,{'MCP_REQUESTS_PER_MINUTE':'1'}):
            with TestClient(crear_app(),base_url='http://localhost') as client:
                headers={'Accept':'application/json, text/event-stream'}
                payload={'jsonrpc':'2.0','id':1,'method':'tools/list'}
                self.assertEqual(client.post('/mcp',headers=headers,json=payload).status_code,200)
                respuesta=client.post('/mcp',headers=headers,json=payload)
                self.assertEqual(respuesta.status_code,429)
                self.assertEqual(respuesta.headers['Retry-After'],'60')
                self.assertEqual(client.get('/healthz').status_code,200)

    def test_hostname_publico_explicito_conserva_proteccion(self):
        with patch.dict(os.environ,{'MCP_PUBLIC_URL':'https://nom.example.org'}):
            seguridad=configuracion_seguridad()
            self.assertTrue(seguridad.enable_dns_rebinding_protection)
            self.assertIn('nom.example.org',seguridad.allowed_hosts)
        with patch.dict(os.environ,{'MCP_PUBLIC_URL':'http://nom.example.org'}):
            with self.assertRaises(ValueError):configuracion_seguridad()
