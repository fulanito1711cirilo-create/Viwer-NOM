import unittest
from core.indice import _construir_indice_jerarquico, _filtrar_indice


class IndiceTests(unittest.TestCase):
    def test_busqueda_preserva_subreferencias_y_pagina_cero(self):
        indice = _construir_indice_jerarquico({'art1': 0, 'art1-2': 1, 'tab2': 3})
        filtrado = _filtrar_indice(indice, 'ART1')
        self.assertEqual(filtrado['articulos']['art1']['pagina'], 0)
        self.assertIn('art1-2', filtrado['articulos']['art1']['subs'])
        self.assertFalse(filtrado['tablas'])
        self.assertIn('tab2', indice['tablas'])
