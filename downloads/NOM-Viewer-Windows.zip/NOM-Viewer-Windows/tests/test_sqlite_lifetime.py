"""Regresión del bloqueo WinError 32: no depender de GC para cerrar SQLite."""
import hashlib
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
import pymupdf
from scripts.index_document import generar
from services.search_service import SearchService
from services.nom_corpus import NOMCorpus


class ConexionRastreada(sqlite3.Connection):
    cerrada = False

    def close(self):
        self.cerrada = True
        super().close()


class SQLiteLifetimeTests(unittest.TestCase):
    def setUp(self):
        carpeta=tempfile.TemporaryDirectory()
        self.addCleanup(carpeta.cleanup)
        self.pdf=Path(carpeta.name)/'NOM.pdf'
        with pymupdf.open() as doc:
            pagina=doc.new_page()
            pagina.insert_text((30,50),'ARTÍCULO 250',fontname='hebo')
            pagina.insert_text((30,70),'250-52. Electrodos de puesta a tierra.',fontname='hebo')
            pagina.insert_text((30,90),'ARTÍCULO 280',fontname='hebo')
            doc.save(self.pdf)
        self.conexiones=[]
        conectar_original=sqlite3.connect

        def conectar(*args,**kwargs):
            kwargs['factory']=ConexionRastreada
            db=conectar_original(*args,**kwargs)
            self.conexiones.append(db)
            return db

        parche=patch('sqlite3.connect',side_effect=conectar)
        parche.start()
        self.addCleanup(parche.stop)

    def test_indice_se_cierra_antes_de_reemplazar_y_se_puede_regenerar(self):
        reemplazar_original=Path.replace

        def reemplazar(path,destino):
            if path.name.endswith('.sqlite.tmp'):
                self.assertTrue(self.conexiones)
                self.assertTrue(all(c.cerrada for c in self.conexiones), 'SQLite sigue abierto al reemplazar el archivo')
            return reemplazar_original(path,destino)

        with patch.object(Path,'replace',reemplazar):
            generar(self.pdf)
            generar(self.pdf)
        self.assertTrue(self.pdf.with_suffix('.sqlite').is_file())

    def test_busqueda_y_corpus_cierran_incluso_al_fallar(self):
        generar(self.pdf)
        sha=hashlib.sha256(self.pdf.read_bytes()).hexdigest()
        self.assertTrue(SearchService(self.pdf.with_suffix('.sqlite'),sha).buscar('tierra'))
        with self.assertRaises(ValueError):
            SearchService(self.pdf.with_suffix('.sqlite'),'otra-firma').buscar('tierra')
        corpus=NOMCorpus(self.pdf)
        corpus.auditoria()
        corpus.estructura('art250-52')
        corpus.leer_disposicion('art250-52')
        with self.assertRaises(RuntimeError):
            with corpus._conexion():
                raise RuntimeError('fallo de prueba')
        self.assertTrue(all(c.cerrada for c in self.conexiones))
