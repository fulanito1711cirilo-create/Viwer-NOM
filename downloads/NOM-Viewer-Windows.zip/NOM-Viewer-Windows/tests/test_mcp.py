"""Handshake real por stdio; requiere requirements-mcp.txt."""
import asyncio
import importlib.util
from pathlib import Path
import sys
import tempfile
import pymupdf
import unittest
from ui.state import ruta_pdf


@unittest.skipUnless(importlib.util.find_spec('mcp'), 'SDK MCP opcional no instalado')
class MCPTests(unittest.TestCase):
    def setUp(self):
        self.temporal = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporal.cleanup)
        self.pdf = ruta_pdf()
        if not self.pdf.with_suffix('.sqlite').is_file():
            from scripts.index_document import generar
            self.pdf = Path(self.temporal.name) / 'NOM.pdf'
            with pymupdf.open() as doc:
                pagina = doc.new_page()
                pagina.insert_text((30,50),'ARTÍCULO 250',fontname='hebo')
                pagina.insert_text((30,70),'250-52. Electrodos de puesta a tierra.',fontname='hebo')
                pagina.insert_text((30,90),'a) Regla de puesta a tierra.')
                pagina.insert_text((30,110),'ARTÍCULO 280',fontname='hebo')
                doc.save(self.pdf)
            generar(self.pdf)

    def test_cliente_stdio(self):
        async def verificar():
            from mcp import ClientSession, StdioServerParameters
            from mcp.client.stdio import stdio_client
            server = str(Path(__file__).resolve().parents[1] / 'mcp_server.py')
            async with stdio_client(StdioServerParameters(command=sys.executable, args=[server], env={'NOM_PDF_PATH':str(self.pdf),'PYTHONDONTWRITEBYTECODE':'1'})) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    tools = await session.list_tools()
                    self.assertEqual(len(tools.tools), 16)
                    for name, args in [('documento_nom', {}), ('dimensionar_tierra_equipos', {'corriente_dispositivo_a':400,'material':'Cobre'}), ('calcular_puesta_tierra', {'voltaje_linea_neutro_v':127,'resistencia_tierra_ohm':40,'material_conductor':'Cobre'}), ('consultar_tabla', {'referencia':'tab310-15b16'}), ('leer_disposicion', {'referencia':'art250-52'}), ('estructura_referencia', {'referencia':'art250'}), ('auditoria_corpus', {}), ('buscar_nom', {'consulta':'puesta a tierra'}),
                                       ('resolver_referencia', {'referencia':'art250'}),
                                       ('leer_pagina', {'pagina':1, 'caracteres':100})]:
                        result = await session.call_tool(name,args)
                        self.assertFalse(result.isError)
                    calculo = await session.call_tool('calcular_caida_tension', {'tipo_circuito':'Trifásico', 'material':'cobre', 'conduit':'PVC', 'calibre':'10', 'longitud_m':50, 'corriente_a':20, 'voltaje_v':220, 'factor_potencia':0.85})
                    self.assertFalse(calculo.isError)
                    invalid = await session.call_tool('leer_pagina', {'pagina':0})
                    self.assertTrue(invalid.isError)
                    from services.nom_corpus import NOMCorpus
                    fingerprint = NOMCorpus(self.pdf).sha256
                    resource = await session.read_resource(f'nom://{fingerprint}/paginas/1')
                    self.assertTrue(resource.contents)
        asyncio.run(asyncio.wait_for(verificar(), timeout=20))
