from pathlib import Path
import unittest
from services.nom_corpus import NOMCorpus
from ui.state import ruta_pdf


@unittest.skipUnless(ruta_pdf().with_suffix('.sqlite').is_file(), 'Índice real opcional no instalado')
class CorpusTests(unittest.TestCase):
    def setUp(self):
        self.corpus = NOMCorpus(ruta_pdf())

    def test_fragmentos_y_citas(self):
        primero = self.corpus.leer_pagina(117, caracteres=100)
        segundo = self.corpus.leer_pagina(117, desplazamiento=100, caracteres=100)
        total = self.corpus.leer_pagina(117, caracteres=12000)
        self.assertEqual(primero['texto'] + segundo['texto'], total['texto'][:200])
        self.assertEqual(primero['siguiente_desplazamiento'], 100)
        self.assertEqual(primero['cita']['sha256'], self.corpus.sha256)
        with self.assertRaises(ValueError):
            self.corpus.leer_pagina(0)

    def test_referencias_y_consultas(self):
        self.assertEqual(self.corpus.resolver('art250')['cita']['pagina_pdf'],117)
        parte = self.corpus.listar('art250', limite=2)
        self.assertEqual(len(parte['referencias']),2)
        self.assertEqual(parte['siguiente_desplazamiento'],2)
        self.assertTrue(self.corpus.buscar('puesta a tierra'))
        with self.assertRaises(ValueError):
            self.corpus.resolver('desconocido')

    def test_disposicion_completa_por_fragmentos(self):
        unidad = self.corpus.estructura('art250-52')
        self.assertEqual(unidad['cita_inicio']['pagina_pdf'],133)
        self.assertEqual(unidad['padre'],'art250')
        self.assertFalse(unidad['revision_humana'])
        offset = 0
        textos = []
        while True:
            parte = self.corpus.leer_disposicion('art250-52',offset,700)
            textos.extend(f['texto'] for f in parte['fragmentos'])
            for f in parte['fragmentos']:
                pagina = self.corpus.leer_pagina(f['cita']['pagina_pdf'],caracteres=12000)['texto']
                self.assertEqual(f['texto'],pagina[f['offset_inicio']:f['offset_fin']])
            offset = parte['siguiente_desplazamiento']
            if offset is None:
                break
        contenido = ''.join(textos)
        self.assertTrue(contenido.startswith('250-52.'))
        self.assertNotIn('250-53.',contenido)
        self.assertEqual(len(contenido),parte['total_caracteres'])
        self.assertTrue(unidad['subdivisiones'])

    def test_ambiguedad_rechazada_y_auditoria_visible(self):
        informe = self.corpus.auditoria()
        self.assertFalse(informe['revision_humana'])
        self.assertEqual(informe['claves_repetidas'], [])
        descartados = informe['candidatos_descartados']
        self.assertTrue(any(e['clave']=='art310-15' and e['razon']=='cita_en_texto_normal' for e in descartados))
        unidad = self.corpus.estructura('art310-15')
        self.assertEqual(unidad['cita_inicio']['pagina_pdf'],184)

    def test_documento_sustituido_no_conserva_citas_antiguas(self):
        import tempfile
        from shutil import copyfile
        with tempfile.TemporaryDirectory() as tmp:
            copia = Path(tmp) / 'NOM.pdf'
            copyfile(ruta_pdf(),copia)
            copyfile(ruta_pdf().with_suffix('.references.json'),copia.with_suffix('.references.json'))
            corpus = NOMCorpus(copia)
            with copia.open('ab') as archivo:
                archivo.write(b'\n')
            with self.assertRaisesRegex(ValueError,'cambió'):
                corpus.leer_pagina(1)
