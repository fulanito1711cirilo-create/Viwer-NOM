import unittest
from streamlit.testing.v1 import AppTest
from tests.test_pdf import documento
from pathlib import Path
APP = str(Path(__file__).resolve().parents[1] / 'app.py')


class AppTests(unittest.TestCase):
    def test_flujo_completo_y_sesiones(self):
        at = AppTest.from_file(APP).run()
        for opt in at.sidebar.radio[0].options:
            at.sidebar.radio[0].set_value(opt).run()
            self.assertFalse(at.exception)
        at.sidebar.radio[0].set_value('🧮 Calculadoras').run()
        for opcion, clave in zip(at.selectbox(key='calculadora_activa').options, ['cdt', 'cc', 'cg', 'pt', 'tr', 'ptt']):
            at.selectbox(key='calculadora_activa').set_value(opcion).run()
            at.text_input(key='elem_' + clave).set_value('Prueba ' + clave)
            at.button(key='btn_' + clave).click().run()
            self.assertFalse(at.exception)
            self.assertFalse(at.error)
        at.selectbox(key='calculadora_activa').set_value('Caída de Tensión').run()
        at.text_input(key='elem_cdt').set_value('Principal')
        at.button(key='btn_cdt').click().run()
        self.assertFalse(at.exception)
        self.assertFalse(at.error)
        self.assertTrue(at.session_state['resultados'])
        at.sidebar.radio[0].set_value('✅ Validación').run()
        self.assertFalse(at.exception)
        at.sidebar.radio[0].set_value('📋 Resultados Acumulados').run()
        at.button(key='exportar_pdf').click().run()
        self.assertFalse(at.exception)
        self.assertFalse(at.error)
        at.session_state['pdf_service'].cargar_desde_bytes(documento())
        at.sidebar.radio[0].set_value('📄 Visor NOM').run()
        self.assertFalse(at.exception)
        at.button(key='v_sig').click().run()
        self.assertEqual(at.session_state['pagina_pdf'], 1)
        at.select_slider(key='v_zoom').set_value(3.0).run()
        self.assertFalse(at.exception)
        other = AppTest.from_file(APP).run()
        self.assertIsNot(other.session_state['pdf_service'], at.session_state['pdf_service'])
        self.assertNotEqual(other.session_state['pdf_service'].document_id, at.session_state['pdf_service'].document_id)
        self.assertFalse(other.session_state['elementos'])
