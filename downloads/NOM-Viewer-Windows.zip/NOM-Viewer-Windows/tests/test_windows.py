import io
import json
from pathlib import Path, PureWindowsPath
import tempfile
import unittest
from unittest.mock import patch
from windows.instalar import configuracion_local
from windows.launcher import esperar_url, iniciar


class Proceso:
    def __init__(self,texto=''):
        self.stdout=io.StringIO(texto)
        self.returncode=None
        self.terminado=False

    def poll(self):return self.returncode
    def terminate(self):self.terminado=True;self.returncode=0
    def wait(self,timeout=None):return self.returncode
    def kill(self):self.terminate()


class WindowsLauncherTests(unittest.TestCase):
    def test_configuracion_preserva_rutas_windows_con_espacios(self):
        raiz=PureWindowsPath('C:/Users/José/Documents/NOM Viewer')
        python=raiz/'.venv/Scripts/python.exe'
        config=json.loads(json.dumps(configuracion_local(raiz,python),ensure_ascii=False))
        servidor=config['mcpServers']['nom-2012']
        self.assertEqual(servidor['command'],str(python))
        self.assertEqual(servidor['env']['NOM_PDF_PATH'],str(raiz/'data/NOM.pdf'))

    def test_detecta_url_real_y_rechaza_host_ajeno(self):
        log=io.StringIO()
        proceso=Proceso('error https://api.trycloudflare.com/tunnel\nURL falsa https://nombre.trycloudflare.com.ajeno.test\n| https://uno-dos-tres.trycloudflare.com |\n')
        self.assertEqual(esperar_url(proceso,log,timeout=1),'https://uno-dos-tres.trycloudflare.com')
        proceso._nom_log_thread.join(timeout=1)
        self.assertIn('api.trycloudflare',log.getvalue())
        with self.assertRaises(RuntimeError):
            esperar_url(Proceso('no se pudo conectar\n'),io.StringIO(),timeout=1)

    def test_ctrl_c_detiene_solo_sus_procesos_y_guarda_estado(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'data').mkdir();(root/'data/NOM.sqlite').touch()
            tunnel,servidor=Proceso(),Proceso()
            with patch('windows.launcher.ROOT',root), patch('windows.launcher.puerto_libre',return_value=8123), \
                 patch('windows.launcher.instalar_cloudflared',return_value=Path('cloudflared')), \
                 patch('windows.launcher.esperar_url',return_value='https://uno-dos.trycloudflare.com'), \
                 patch('windows.launcher.esperar_salud'),patch('windows.launcher.subprocess.run'), \
                 patch('windows.launcher.subprocess.Popen',side_effect=[tunnel,servidor]) as crear, \
                 patch('windows.launcher.time.sleep',side_effect=KeyboardInterrupt):
                with self.assertRaises(KeyboardInterrupt):iniciar(True)
            self.assertTrue(tunnel.terminado)
            self.assertTrue(servidor.terminado)
            entorno=crear.call_args_list[1].kwargs['env']
            self.assertEqual(entorno['MCP_PUBLIC_URL'],'https://uno-dos.trycloudflare.com')
            self.assertEqual(entorno['MCP_BIND_HOST'],'127.0.0.1')
            estado=json.loads((root/'.local/windows/conexion.json').read_text(encoding='utf-8'))
            self.assertEqual(estado['estado'],'detenido')

    def test_no_anuncia_url_si_la_comprobacion_publica_falla(self):
        import subprocess
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'data').mkdir();(root/'data/NOM.sqlite').touch()
            tunnel,servidor=Proceso(),Proceso()
            with patch('windows.launcher.ROOT',root),patch('windows.launcher.puerto_libre',return_value=8123), \
                 patch('windows.launcher.instalar_cloudflared',return_value=Path('cloudflared')), \
                 patch('windows.launcher.esperar_url',return_value='https://uno-dos.trycloudflare.com'), \
                 patch('windows.launcher.esperar_salud'), \
                 patch('windows.launcher.subprocess.Popen',side_effect=[tunnel,servidor]), \
                 patch('windows.launcher.subprocess.run',side_effect=subprocess.CalledProcessError(1,'check')):
                with self.assertRaises(subprocess.CalledProcessError):iniciar(True)
            self.assertTrue(tunnel.terminado and servidor.terminado)
            self.assertFalse((root/'.local/windows/URL-MCP.txt').exists())
