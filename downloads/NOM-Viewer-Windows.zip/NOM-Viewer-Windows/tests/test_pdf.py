import unittest
import pymupdf as fitz
from services.pdf_service import PDFService, ArchivoInvalidoError, ArticuloNoEncontradoError


def documento(texto='prueba', paginas=2):
    with fitz.open() as doc:
        for _ in range(paginas):
            doc.new_page().insert_text((72, 72), texto)
        return doc.tobytes()


class PDFTests(unittest.TestCase):
    def test_zoom_y_cache(self):
        svc = PDFService(cache_paginas=2).cargar_desde_bytes(documento())
        a = svc.renderizar_pagina(0, 1)
        self.assertIs(a, svc.renderizar_pagina(0, 1))
        b = svc.renderizar_pagina(0, 2)
        self.assertEqual(fitz.Pixmap(b.imagen).width, fitz.Pixmap(a.imagen).width * 2)
        svc.renderizar_pagina(1, 1)
        self.assertEqual(len(svc._cache), 2)
        self.assertNotIn((0, 1.0), svc._cache)
        svc.close()

    def test_preserva_documento_ante_archivo_invalido(self):
        svc = PDFService().cargar_desde_bytes(documento())
        with self.assertRaises(ArchivoInvalidoError):
            svc.cargar_desde_bytes(b'invalido')
        self.assertEqual(svc.total_paginas, 2)
        svc.close()

    def test_aislamiento_y_reemplazo(self):
        a, b = PDFService(), PDFService()
        a.cargar_desde_bytes(documento())
        self.assertFalse(b.esta_cargado)
        a.renderizar_pagina(0)
        old = a._doc
        a.cargar_desde_bytes(documento('nuevo', 1))
        self.assertTrue(old.is_closed)
        self.assertFalse(a._cache)
        a.close()

    def test_limite_memoria_y_referencias(self):
        svc = PDFService({'art1': 50}, cache_bytes=1).cargar_desde_bytes(documento())
        svc.renderizar_pagina(0)
        self.assertFalse(svc._cache)
        with self.assertRaises(ArticuloNoEncontradoError):
            svc.pagina_de_articulo('art1')
        with self.assertRaises(ValueError):
            svc.renderizar_pagina(0, float('nan'))
        svc.close()
