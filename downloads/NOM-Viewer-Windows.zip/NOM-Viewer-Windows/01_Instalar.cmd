@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" goto local_python
if exist "%ProgramFiles%\Python312\python.exe" goto machine_python
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 goto py_launcher
where winget >nul 2>&1
if errorlevel 1 goto falta_python
echo Instalando Python 3.12 mediante winget...
winget install --exact --id Python.Python.3.12 --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity
if errorlevel 1 goto falta_python
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" goto local_python
if exist "%ProgramFiles%\Python312\python.exe" goto machine_python
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 goto py_launcher
echo Cierra esta ventana y vuelve a ejecutar 01_Instalar.cmd.
set "NOM_EXIT=1"
goto finalizar
:local_python
"%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%~dp0windows\instalar.py"
set "NOM_EXIT=%ERRORLEVEL%"
goto finalizar
:machine_python
"%ProgramFiles%\Python312\python.exe" "%~dp0windows\instalar.py"
set "NOM_EXIT=%ERRORLEVEL%"
goto finalizar
:py_launcher
py -3.12 "%~dp0windows\instalar.py"
set "NOM_EXIT=%ERRORLEVEL%"
goto finalizar
:falta_python
echo Instala Python 3.12 de 64 bits desde https://www.python.org/downloads/windows/
echo Activa el lanzador Python y vuelve a ejecutar este archivo.
set "NOM_EXIT=1"
:finalizar
if not "%NOM_EXIT%"=="0" echo No se completo la instalacion. Revisa los mensajes anteriores.
pause
exit /b %NOM_EXIT%
