"""Empaqueta los fuentes y el PDF; excluye entornos, credenciales y proyectos locales."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def crear(destino):
    archivos=[]
    for nombre in ['LEEME-WINDOWS.txt','README.md','app.py','mcp_server.py','http_server.py',
                   'requirements.txt','requirements-mcp.txt','data/NOM.pdf',
                   '01_Instalar.cmd','02_Publicar_MCP.cmd','03_Abrir_Visor.cmd',
                   '04_MCP_Solo_Local.cmd','05_Probar_MCP.cmd']:
        archivos.append(ROOT/nombre)
    for nombre in ['core','config','services','ui','windows','scripts','docs','tests']:
        for path in sorted((ROOT/nombre).rglob('*')):
            if path.is_symlink():
                raise ValueError('El paquete no admite enlaces simbólicos.')
            if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
                archivos.append(path)
    manifest={'producto':'NOM Viewer para Windows','motor_version':'0.2.0',
              'plataforma':'Windows 10/11 x64, Python 3.12',
              'archivos':{str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in archivos}}
    with zipfile.ZipFile(destino,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archivo:
        for path in archivos:
            archivo.write(path,str(Path('NOM-Viewer-Windows')/path.relative_to(ROOT)).replace('\\','/'))
        archivo.writestr('NOM-Viewer-Windows/ARCHIVOS-SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(destino) as archivo:
        corrupto=archivo.testzip()
        if corrupto:
            raise ValueError('ZIP inválido: '+corrupto)
    print(f'ZIP: {destino}\nArchivos: {len(archivos)+1}\nBytes: {Path(destino).stat().st_size}')
    print('SHA256: '+hashlib.sha256(Path(destino).read_bytes()).hexdigest())


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT.parent/'NOM-Viewer-Windows.zip')
    crear(parser.parse_args().output)
