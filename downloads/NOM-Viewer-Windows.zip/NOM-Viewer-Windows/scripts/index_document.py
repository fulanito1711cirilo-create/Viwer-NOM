"""Genera índice de búsqueda y referencias reproducibles para un PDF local."""
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys
import pymupdf

# Permite ejecutar el script desde cualquier directorio.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.estructura import segmentar


def generar(path):
    path = Path(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    target = path.with_suffix('.sqlite')
    temp = target.with_suffix('.sqlite.tmp')
    temp.unlink(missing_ok=True)
    referencias = {}
    paginas = []
    evidencias = {}
    with sqlite3.connect(temp) as db, pymupdf.open(path) as doc:
        db.execute('CREATE TABLE metadata (sha256 TEXT, paginas INTEGER)')
        db.execute('INSERT INTO metadata VALUES (?, ?)', (digest, len(doc)))
        db.execute("CREATE VIRTUAL TABLE paginas USING fts5(texto, tokenize='unicode61 remove_diacritics 2')")
        for num, page in enumerate(doc):
            texto = page.get_text()
            paginas.append(texto)
            evidencias[num] = []
            for bloque in page.get_text('dict')['blocks']:
                for linea in bloque.get('lines', []):
                    for span in linea['spans']:
                        if re.match(r'^\s*\d+-\d+\.', span['text']):
                            evidencias[num].append({'texto':span['text'], 'negrita':bool(span['flags'] & 16),
                                                    'fuente':span['font'], 'bbox':list(span['bbox'])})
            db.execute('INSERT INTO paginas(rowid, texto) VALUES (?, ?)', (num + 1, texto))
            for patron, prefijo in [(r'^[ \t]*ART[ÍI]CULO[ \t]+(\d+)[ \t]*$', 'art'),
                                     (r'^[ \t]*(\d+-\d+)\.\s', 'art'),
                                     (r'^[ \t]*Tabla[ \t]+(\d+(?:-\d+)?(?:\([A-Za-z0-9]+\))*)[.\s]', 'tab')]:
                for m in re.finditer(patron, texto, re.MULTILINE):
                    if prefijo == 'tab' and num < 20:
                        continue
                    clave = prefijo + re.sub(r'[^a-z0-9-]', '', m[1].lower())
                    referencias.setdefault(clave, num)
        unidades, reporte = segmentar(paginas, evidencias)
        # Las secciones aceptadas sustituyen localizaciones preliminares de citas.
        referencias = {k:v for k,v in referencias.items() if not re.fullmatch(r'art\d+-\d+', k)}
        for unidad in unidades:
            referencias.setdefault(unidad['clave'], unidad['pagina'])
        from core.tablas import DATOS
        if digest == DATOS['sha256']:
            for clave, tabla in DATOS['tablas'].items():
                referencias[clave] = tabla['pagina_pdf'] - 1
        db.execute('CREATE TABLE unidades (id INTEGER PRIMARY KEY, clave TEXT, padre TEXT, datos TEXT)')
        db.executemany('INSERT INTO unidades(clave, padre, datos) VALUES (?, ?, ?)',
                       [(u['clave'], u['padre'], json.dumps(u, ensure_ascii=False)) for u in unidades])
        db.execute('CREATE INDEX unidades_clave ON unidades(clave)')
        db.execute('CREATE INDEX unidades_padre ON unidades(padre)')
        db.execute('CREATE TABLE auditoria (datos TEXT)')
        db.execute('INSERT INTO auditoria VALUES (?)', (json.dumps(reporte, ensure_ascii=False),))
    temp.replace(target)
    path.with_suffix('.references.json').write_text(json.dumps({'sha256':digest, 'referencias':referencias}, ensure_ascii=False, indent=2),encoding='utf-8')
    path.with_suffix('.audit.json').write_text(json.dumps({'sha256':digest, **reporte}, ensure_ascii=False, indent=2),encoding='utf-8')
    print(f'{len(paginas)} páginas: {len(referencias)} referencias; SHA256 {digest}')

if __name__ == '__main__':
    generar(sys.argv[1] if len(sys.argv) > 1 else 'data/NOM.pdf')
