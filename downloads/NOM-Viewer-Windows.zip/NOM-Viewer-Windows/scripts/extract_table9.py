"""Extrae las columnas de Tabla 9 del PDF identificado; falla ante otra disposición."""
import hashlib
import json
from pathlib import Path
import re
import sys
import pymupdf


def extraer(pdf, destino):
    pdf, destino = Path(pdf), Path(destino)
    datos = json.loads(destino.read_text(encoding='utf-8'))
    if hashlib.sha256(pdf.read_bytes()).hexdigest() != datos['sha256']:
        raise ValueError('Este extractor solo está validado para el PDF identificado.')
    with pymupdf.open(pdf) as doc:
        texto = doc[1010].get_text()
    inicio = re.search(r'\n2\.08\s*\n14\s*\n',texto)
    if not inicio:
        raise ValueError('No se encontró la primera fila esperada.')
    tokens = [s.strip() for s in texto[inicio.start():texto.index('\nNotas:')].splitlines() if s.strip()]
    if len(tokens) != 21 * 16:
        raise ValueError('Cambió la estructura de columnas de la Tabla 9.')
    filas = [tokens[i:i+16] for i in range(0,len(tokens),16)]
    tabla = {'pagina_pdf':1011, 'unidad':'ohm/km', 'temperatura_c':75,'frecuencia_hz':60,
             'alcance':'Cables de 600 V, tres conductores individuales en un conduit; revisar configuración y notas originales. Ze_085 solo para FP=0.85.',
             'notas_originales':texto[texto.index('Notas:'):], 'cobre':{}, 'aluminio':{}}
    for fila in filas:
        calibre = fila[1]
        x = [float(fila[2]), float(fila[2]), float(fila[3])]
        for material,base,zbase in [('cobre',4,10),('aluminio',7,13)]:
            if fila[base] in ('––','—','-'):
                continue
            tabla[material][calibre] = {conduit:{'R':float(fila[base+i]), 'X':x[i], 'Ze_085':float(fila[zbase+i])}
                                        for i,conduit in enumerate(['PVC','Aluminio','Acero'])}
    datos['tablas']['tab9'] = tabla
    destino.write_text(json.dumps(datos,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

if __name__ == '__main__':
    extraer(sys.argv[1] if len(sys.argv)>1 else 'data/NOM.pdf',
            sys.argv[2] if len(sys.argv)>2 else 'config/normas/tablas_75c.json')
