"""Medición local reproducible de caché. Ejecutar desde la raíz del repositorio."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from statistics import median
from time import perf_counter
import pymupdf as fitz
from services.pdf_service import PDFService

with fitz.open() as doc:
    page = doc.new_page()
    for y in range(40, 780, 15):
        page.insert_text((40, y), 'NOM Viewer: documento sintetico de rendimiento. ' * 2)
    svc = PDFService().cargar_desde_bytes(doc.tobytes())
start = perf_counter()
svc.renderizar_pagina(0, 2)
cold = perf_counter() - start
hits = []
for _ in range(1000):
    start = perf_counter()
    svc.renderizar_pagina(0, 2)
    hits.append(perf_counter() - start)
print(f'Primer render: {cold * 1000:.3f} ms')
print(f'Mediana de 1000 aciertos de cache: {median(hits) * 1000:.6f} ms')
print(f'Imagen PNG retenida: {svc._cache_bytes:,} bytes')
svc.close()
