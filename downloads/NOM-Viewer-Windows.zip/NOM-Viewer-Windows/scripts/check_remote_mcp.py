"""Verifica una URL MCP HTTP con el cliente oficial, sin modificar datos remotos."""
import argparse
import asyncio
from urllib.parse import urlsplit
import httpx
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client


async def verificar(url):
    partes=urlsplit(url)
    if partes.scheme not in ('https','http') or not partes.hostname or partes.username or partes.password:
        raise ValueError('Indica una URL HTTPS sin credenciales.')
    if partes.scheme=='http' and partes.hostname not in ('localhost','127.0.0.1'):
        raise ValueError('HTTP sin TLS solo se admite para pruebas locales.')
    async with httpx.AsyncClient(timeout=20) as client:
        salud=await client.get(f'{partes.scheme}://{partes.netloc}/healthz')
        salud.raise_for_status()
        async with streamable_http_client(url,http_client=client) as (read,write,_):
            async with ClientSession(read,write) as sesion:
                await sesion.initialize()
                herramientas=await sesion.list_tools()
                esperadas={'documento_nom','buscar_nom','leer_disposicion','consultar_tabla','dimensionar_tierra_equipos'}
                if not esperadas.issubset({t.name for t in herramientas.tools}):
                    raise ValueError('El servidor no expone las herramientas esperadas de NOM Viewer.')
                for nombre,argumentos in [('documento_nom',{}),('buscar_nom',{'consulta':'puesta a tierra','limite':1})]:
                    resultado=await sesion.call_tool(nombre,argumentos)
                    if resultado.isError:
                        raise ValueError(f'La herramienta {nombre} devolvió un error.')
                print(f'OK: salud, conexión MCP, {len(herramientas.tools)} herramientas y consultas.')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('url',help='URL completa del endpoint, terminada en /mcp')
    args=parser.parse_args()
    asyncio.run(asyncio.wait_for(verificar(args.url),timeout=45))
