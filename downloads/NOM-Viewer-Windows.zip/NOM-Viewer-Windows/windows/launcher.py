"""Inicia los servicios locales y, opcionalmente, un túnel temporal de Cloudflare."""
import argparse
import json
import os
from pathlib import Path
import queue
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import uuid
from urllib.request import urlopen

ROOT=Path(__file__).resolve().parents[1]
URL_TUNEL=re.compile(r'https://[a-z0-9]+(?:-[a-z0-9]+)*\.trycloudflare\.com(?=[\s|]|$)')


def detectar_cloudflared():
    encontrado=shutil.which('cloudflared')
    if encontrado:
        return Path(encontrado)
    local=os.environ.get('LOCALAPPDATA')
    if local:
        candidatos=[Path(local)/'Microsoft/WinGet/Links/cloudflared.exe']
        paquetes=Path(local)/'Microsoft/WinGet/Packages'
        if paquetes.is_dir():
            candidatos.extend(paquetes.glob('Cloudflare.cloudflared_*/cloudflared.exe'))
        for candidato in candidatos:
            if candidato.is_file():
                return candidato
    programas=os.environ.get('ProgramFiles')
    if programas:
        for candidato in [Path(programas)/'WinGet/Links/cloudflared.exe',Path(programas)/'cloudflared/cloudflared.exe']:
            if candidato.is_file():
                return candidato
    return None


def instalar_cloudflared():
    exe=detectar_cloudflared()
    if exe:
        return exe
    winget=shutil.which('winget')
    if not winget:
        raise RuntimeError('Falta cloudflared. Instala App Installer/winget y ejecuta: winget install --exact --id Cloudflare.cloudflared')
    print('Instalando Cloudflare Tunnel con winget (verificación del paquete activa)...',flush=True)
    subprocess.run([winget,'install','--exact','--id','Cloudflare.cloudflared','--source','winget',
                    '--accept-package-agreements','--accept-source-agreements','--disable-interactivity'],check=True)
    exe=detectar_cloudflared()
    if not exe:
        raise RuntimeError('Cloudflare se instaló, pero su comando aún no está disponible. Cierra esta ventana y vuelve a abrir 02_Publicar_MCP.cmd.')
    return exe


def puerto_libre():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        return s.getsockname()[1]


def esperar_url(proceso,log,timeout=90):
    mensajes=queue.Queue()

    def leer():
        for linea in proceso.stdout:
            log.write(linea)
            log.flush()
            mensajes.put(linea)
        mensajes.put(None)

    proceso._nom_log_thread=threading.Thread(target=leer,daemon=True)
    proceso._nom_log_thread.start()
    fin=time.monotonic()+timeout
    while time.monotonic()<fin:
        try:
            linea=mensajes.get(timeout=min(1,max(.01,fin-time.monotonic())))
        except queue.Empty:
            if proceso.poll() is not None:
                break
            continue
        if linea is None:
            break
        coincidencia=URL_TUNEL.search(linea)
        if coincidencia and coincidencia[0]!='https://api.trycloudflare.com':
            return coincidencia[0]
    raise RuntimeError('No se pudo crear el túnel. Consulta .local/windows/tunnel.log. Puede haber una restricción de red o una configuración cloudflared previa.')


def esperar_salud(proceso,port,timeout=45,url=None):
    fin=time.monotonic()+timeout
    while time.monotonic()<fin:
        if proceso.poll() is not None:
            raise RuntimeError('El servidor se cerró. Consulta .local/windows/http.log.')
        try:
            with urlopen(url or f'http://127.0.0.1:{port}/healthz',timeout=2) as respuesta:
                if json.load(respuesta).get('status')=='ok':
                    return
        except (OSError,ValueError):
            time.sleep(.25)
    raise RuntimeError('El servidor no respondió a tiempo. Consulta .local/windows/http.log.')


def detener(proceso):
    if proceso and proceso.poll() is None:
        proceso.terminate()
        try:
            proceso.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proceso.kill()
            proceso.wait(timeout=5)
    lector=getattr(proceso,'_nom_log_thread',None)
    if lector:
        lector.join(timeout=2)


def iniciar(publico):
    if not (ROOT/'data/NOM.sqlite').is_file():
        raise RuntimeError('Primero ejecuta 01_Instalar.cmd.')
    destino=ROOT/'.local/windows'
    destino.mkdir(parents=True,exist_ok=True)
    port=puerto_libre()
    tunnel=None
    servidor=None
    flags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0
    run_id=uuid.uuid4().hex
    log_tunel=(destino/'tunnel.log').open('w',encoding='utf-8')
    log_http=(destino/'http.log').open('w',encoding='utf-8')
    try:
        origen=None
        if publico:
            exe=instalar_cloudflared()
            print('Creando un túnel HTTPS temporal. No necesita cuenta Render...',flush=True)
            tunnel=subprocess.Popen([str(exe),'tunnel','--url',f'http://127.0.0.1:{port}','--no-autoupdate','--protocol','http2'],
                  cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',creationflags=flags)
            origen=esperar_url(tunnel,log_tunel)
        entorno=os.environ.copy()
        entorno.update({'PORT':str(port),'MCP_BIND_HOST':'127.0.0.1','NOM_PDF_PATH':str(ROOT/'data/NOM.pdf'),'PYTHONDONTWRITEBYTECODE':'1'})
        if origen:
            entorno['MCP_PUBLIC_URL']=origen
        servidor=subprocess.Popen([sys.executable,str(ROOT/'http_server.py')],cwd=ROOT,env=entorno,
                                   stdout=log_http,stderr=subprocess.STDOUT,creationflags=flags)
        esperar_salud(servidor,port)
        url=(origen or f'http://127.0.0.1:{port}')+'/mcp'
        if publico:
            print('Comprobando la conexión HTTPS pública...',flush=True)
            esperar_salud(servidor,port,timeout=60,url=origen+'/healthz')
            subprocess.run([sys.executable,str(ROOT/'scripts/check_remote_mcp.py'),url],cwd=ROOT,check=True,timeout=50)
        info={'url':url,'puerto_local':port,'publico':publico,'estado':'activo','run_id':run_id}
        (destino/'conexion.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
        (destino/'URL-MCP.txt').write_text(url+'\n',encoding='utf-8')
        print('\nMCP LISTO. URL para conectar tu agente:\n\n'+url+'\n',flush=True)
        print('Autenticación: ninguna. Mantén esta ventana y la PC encendidas.',flush=True)
        if publico:
            print('La URL es pública y temporal: cambia al reiniciar. Solo publica la NOM y sus herramientas; no tus archivos de proyecto.',flush=True)
        print('La dirección se guardó en .local/windows/URL-MCP.txt. Ctrl+C para detener.',flush=True)
        while servidor.poll() is None:
            if tunnel and tunnel.poll() is not None:
                raise RuntimeError('El túnel se cerró; vuelve a ejecutar el acceso para obtener otra URL.')
            time.sleep(.5)
        raise RuntimeError('El servidor se cerró; revisa .local/windows/http.log.')
    finally:
        detener(servidor)
        detener(tunnel)
        log_tunel.close()
        log_http.close()
        archivo=destino/'conexion.json'
        if archivo.is_file():
            info=json.loads(archivo.read_text(encoding='utf-8'))
            if info.get('run_id')==run_id:
                info['estado']='detenido'
                archivo.write_text(json.dumps(info,indent=2),encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('modo',choices=['publico','local','visor','probar'])
    modo=parser.parse_args().modo
    if modo in ('publico','local'):
        iniciar(modo=='publico')
    elif modo=='visor':
        subprocess.run([sys.executable,'-m','streamlit','run',str(ROOT/'app.py'),'--server.address=127.0.0.1',
                        '--browser.gatherUsageStats=false','--server.headless=false'],cwd=ROOT,check=True)
    else:
        archivo=ROOT/'.local/windows/conexion.json'
        if not archivo.is_file():
            raise RuntimeError('Primero inicia el MCP (02_Publicar_MCP.cmd o 04_MCP_Solo_Local.cmd).')
        info=json.loads(archivo.read_text(encoding='utf-8'))
        if info.get('estado')!='activo':
            raise RuntimeError('El MCP está detenido. Inícialo antes de probar.')
        subprocess.run([sys.executable,str(ROOT/'scripts/check_remote_mcp.py'),f"http://127.0.0.1:{info['puerto_local']}/mcp"],cwd=ROOT,check=True)


if __name__=='__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nServicios detenidos.')
    except (OSError,RuntimeError,ValueError,subprocess.CalledProcessError) as exc:
        print('\nNo se pudo completar: '+str(exc),file=sys.stderr)
        raise SystemExit(1)
