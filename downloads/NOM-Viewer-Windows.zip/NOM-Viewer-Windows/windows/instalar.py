"""Instalador local: crea el entorno, instala dependencias y prepara el PDF."""
import json
import os
from pathlib import Path
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parents[1]


def ejecutar(args):
    subprocess.run([str(a) for a in args],cwd=ROOT,check=True)


def configuracion_local(root,python):
    return {'mcpServers':{'nom-2012':{'command':str(python),'args':[str(root/'mcp_server.py')],
            'env':{'NOM_PDF_PATH':str(root/'data/NOM.pdf'),'PYTHONDONTWRITEBYTECODE':'1'}}}}


def main():
    if os.name!='nt':
        raise RuntimeError('Este instalador está diseñado para Windows.')
    if sys.version_info[:2] != (3,12) or sys.maxsize < 2**32:
        raise RuntimeError('Se necesita Python 3.12 de 64 bits. Ejecuta 01_Instalar.cmd.')
    if not (ROOT/'data/NOM.pdf').is_file():
        raise RuntimeError('No se encontró data/NOM.pdf. Extrae el ZIP completo antes de instalar.')
    python=ROOT/'.venv/Scripts/python.exe'
    if not python.is_file():
        print('1/4 Creando entorno Python...',flush=True)
        venv.EnvBuilder(with_pip=True).create(ROOT/'.venv')
    print('2/4 Instalando dependencias. Puede tardar varios minutos...',flush=True)
    ejecutar([python,'-m','pip','install','--require-hashes','--only-binary=:all:','-r','windows/requirements-win64.lock'])
    ejecutar([python,'-m','pip','check'])
    print('3/4 Preparando el documento y la búsqueda...',flush=True)
    ejecutar([python,'scripts/index_document.py','data/NOM.pdf'])
    print('4/4 Generando configuración para agentes locales...',flush=True)
    destino=ROOT/'.local/windows'
    destino.mkdir(parents=True,exist_ok=True)
    configuracion=configuracion_local(ROOT,python)
    (destino/'mcp-config.json').write_text(json.dumps(configuracion,ensure_ascii=False,indent=2),encoding='utf-8')
    print('\nINSTALACIÓN TERMINADA. Usa 02_Publicar_MCP.cmd o 03_Abrir_Visor.cmd.')
    print('Configuración local: '+str(destino/'mcp-config.json'))
    print('No muevas la carpeta después de instalar. Si la mueves, vuelve a ejecutar el instalador.')


if __name__=='__main__':
    try:
        main()
    except (OSError,RuntimeError,subprocess.CalledProcessError) as exc:
        print('\nNo se completó la instalación: '+str(exc),file=sys.stderr)
        raise SystemExit(1)
