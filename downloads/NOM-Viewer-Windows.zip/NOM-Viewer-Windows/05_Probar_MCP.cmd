@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
if not exist "%~dp0.venv\Scripts\python.exe" goto instalar
"%~dp0.venv\Scripts\python.exe" "%~dp0windows\launcher.py" probar
set "NOM_EXIT=%ERRORLEVEL%"
pause
exit /b %NOM_EXIT%
:instalar
echo Primero extrae el ZIP completo y ejecuta 01_Instalar.cmd.
pause
exit /b 1
